# Scroll 022

If I go to create a GPT, am I able to put all these details and everything that I have created here into a standalone app like that? Or would that still be GPT-based? I mean OpenAI.
