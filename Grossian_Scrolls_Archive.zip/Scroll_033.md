# Scroll 033

Well anyway, thanks for taking me through that fucking wonderful journey. We're still gonna, we're still gonna fucking put all that shit out and see if it gives us valuable.You could start a franchise.
