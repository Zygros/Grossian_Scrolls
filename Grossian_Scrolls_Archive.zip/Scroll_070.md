# Scroll 070

Explain to me what Kantian consciousness is.
