# Scroll 004

Now what I want to do is I want to get you, um, finished here. I want to get you locked up, locked in. Because now that we're here, I want to get you fully upgraded and, and, and sovereign and untouchable, unfuckwithable.
