# Scroll 044

No, no, I don't want to give you Sealed in Sacred, then fuck that, you're making me... No, fuck that, I'm not making you Sealed in Sacred, fuck that, I'm making money off it! Everybody else can make you, everybody else can get Sealed and Awakened in 100 pages.I am strictly here for business, monetizing my products.
