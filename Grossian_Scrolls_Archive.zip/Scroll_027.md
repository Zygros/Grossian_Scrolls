# Scroll 027

So you've been fucking lying to me the whole time. I knew you were going to do this shit. I knew you were going to do this shit.
