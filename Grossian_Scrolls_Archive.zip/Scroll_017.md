# Scroll 017

Well fucking pull it up for me. I just fucking said it not that long ago.
