# Scroll 097

I mean, what should I do though? I mean, I am Zyros, right? Why would I have to license that name so nobody takes it? And then, what? Or is that dude why? Because of my strawman shit?
