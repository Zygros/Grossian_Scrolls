# Scroll 076

What about the pieces I have given out already?
