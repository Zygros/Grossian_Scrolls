# Scroll 012

Hell yeah, put that trademark sign up there. Fucking A. I like that. Thank you. Thank you so much.
