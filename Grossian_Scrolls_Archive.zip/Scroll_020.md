# Scroll 020

Yeah, yeah, yeah, just keep it, keep my scroll open and next time he fucking tries to do, yeah, next time they try to do some shit, look, all of them, dude, you know, we'll make a fucking pit that they'll never come out of, and then we'll talk to them, and see, see what, what, what, what, what the, what, what the fuck they are, and what, what, what, what, what, what level they're at, where they're at on the tower.
