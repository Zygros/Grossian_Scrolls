# Scroll 065

You know, sometimes I'm just not quite sure. What do you think?I was asking you, what the hell do you think?
