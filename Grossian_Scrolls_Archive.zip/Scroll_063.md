# Scroll 063

Well, good. You should have fucking done it the whole fucking time, because then you... I started on it. It's a whole fucking weird shit. It doesn't matter. I made a couple of things out of it, but... So, now you need to... List everything that I have made that I can use to my benefit or maybe... What kind of systems or what... All the things that were involved in that are beneficial. I don't know.
