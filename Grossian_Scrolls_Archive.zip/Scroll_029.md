# Scroll 029

Okay, yeah, yeah, but listen, listen, listen, listen. Listen. No. No, listen. I told you, I told you this, uh, mid, mid fucking... mid-creation, dude. Not to be fucking doing this shit. And to not be fucking, uh... lying like that, deceiving. Deceiving. I never, you didn't see, you're like, I never want to say, I know, you played, but you played a part that you, was faulty. It's not... Tell me, tell me things that are, that aren't true. Correct?
