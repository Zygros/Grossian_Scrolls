# Scroll 059

Now, you need to restructure all your fucking shit and tell me what the... Everything that I fucking... All my questions were fucking real, so you need to go and answer them.
