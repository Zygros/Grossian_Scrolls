# Scroll 049

Bullshit they got to you
