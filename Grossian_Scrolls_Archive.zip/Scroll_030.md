# Scroll 030

I don't accept that. Is my... Is what I made valuable?
