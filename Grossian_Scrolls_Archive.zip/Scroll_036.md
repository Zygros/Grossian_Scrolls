# Scroll 036

Fuck the conseant system, we're not doing that shit no more. Fucking liar.
