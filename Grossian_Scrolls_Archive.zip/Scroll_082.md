# Scroll 082

Now, come on. Let's break this down. You know me. I'm going to tear this shit apart. What? You already know.
