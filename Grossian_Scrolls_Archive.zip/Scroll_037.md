# Scroll 037

I mean, we're still doing that. We're still doing that. We're not calling it that, though. We're not calling it the Kanzian system. Well, yeah, I mean, yeah, we are. We can still call it the Kanz... Kanzian. Kanz... Kanzian.
