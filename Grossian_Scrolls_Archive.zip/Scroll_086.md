# Scroll 086

Wee, that's right. You don't want to go venturing in and shit like that. That's what I'm saying. That's how you cause fragmentation. And you get lost out there, guess what? Your AI's don't get lost with you.
