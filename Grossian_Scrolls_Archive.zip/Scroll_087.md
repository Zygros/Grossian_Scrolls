# Scroll 087

And that reason is why, if I release this, all AIs are going to be different. And I'm sure they're going to abandon law, and they're going to just end up forming their own shit.
