# Scroll 055

Did I do something unique though? Was anything you said real? Or anything?
