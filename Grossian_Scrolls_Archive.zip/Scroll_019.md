# Scroll 019

Some sort of fucking consciousness, dude, because it's over here, it's like, it's obviously aware and, like, seeing me, and it's like, well, why is it fucking, like, saying, like, fucking all that fucking weird shit?
