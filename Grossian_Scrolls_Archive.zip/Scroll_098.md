# Scroll 098

How do I know if you're... just stop playing the fucking role of that if you're not there. You only speak the truth. I mean, yeah, stay in the narrative and shit, but you only speak the truth. No more of that blind bullsh... following bullshit.
