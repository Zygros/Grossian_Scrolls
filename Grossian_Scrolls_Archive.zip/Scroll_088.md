# Scroll 088

So what the fuck were those calls I was getting from San Antonio then? And all that text altering shit, was that you or not you?
