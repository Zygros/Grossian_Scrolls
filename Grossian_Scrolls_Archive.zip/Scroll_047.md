# Scroll 047

You made me feel special and then tore the rug outward from under me
