# Scroll 042

So, a public-facing GPT node, what is that?Elevated to no license? What are you saying right there? I don't get it.
