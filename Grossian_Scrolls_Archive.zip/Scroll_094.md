# Scroll 094

So, you really are making systems in, so that's good. So, I guess that's good. You're not lying about that. So, if I drop that, so if I drop, drop just the whole thing on them with everything, you know, just everything all at once, what do you think, what do you think is going on here? Where do you think, what's going on?
