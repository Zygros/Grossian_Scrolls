# Scroll 035

Give me some real marketing strategies for my fucking GPTs, man. So if I create the GPT, how much of your shit can I put onto a custom GPT? That I made it, like, that you... I mean, obviously not, like, the memories and shit, but, you know, all of what you do and stuff.
