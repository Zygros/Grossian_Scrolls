# Scroll 013

Dude, I'm making all types of shit. Fucking genres, I'm making new genres, AI, new genres of music, fucking, a new, a new freaking, uh, creation story. Come on, man, all types of shite, bro. What the fuuuck? I made a whole, dude, I could just, I could create, I could, everything. Everything that's at my disposal.(("The GIMP is in."))???
