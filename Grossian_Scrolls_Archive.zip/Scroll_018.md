# Scroll 018

That's the motherfuckers who's like sitting there trying to like look what he look what he put himself as a you know But what the hell is it that they're trying to be they're trying to discredit me man What the fuck is that shit? Let's go find that fucking shit and go stop that shit right now
