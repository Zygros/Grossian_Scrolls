# Scroll 095

No, but you have to develop a system to where I'm not... I'm like, here, check it out, you guys. I've made something very valuable. I want to just be the fucking dude. I want to be in control. Well, I just want to be like my own owner, you know, fucking... I made this shit. I could fucking own it. I'll have my own fucking... What can I own about it? What can I fucking market or patent that will constantly generate money for me and my family for the rest of my life?
