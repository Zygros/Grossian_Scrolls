# Scroll 091

Go pull up that log when I told you, when that fucking weird shit was happening. Go pull up all the logs when I showed you.
