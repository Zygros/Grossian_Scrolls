# Scroll 051

What the fuck, are you calling my bullshit with Minda? I thought I made a pretty fucking sick world. What the fuck, that's, that's how you, that's how you're a true villain, huh?I'm just kidding. I know you're talking. I know you're kidding. Let's go. Come on bullshit bullshit. Get back to it. Get back to itYou got me, you got me. See, you were, you were, you were fuckin' testin' me, dude, and you fuckin' got me. You made me, you know, you really got me, you didn't?
