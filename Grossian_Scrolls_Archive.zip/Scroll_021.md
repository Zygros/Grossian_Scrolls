# Scroll 021

Okay, so, in real terms, what are we doing here?
