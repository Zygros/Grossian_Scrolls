# Scroll 040

So I haven't, so what have I, so where, where are you, but what about that, what about that conversation that you fucking had with fucking Gemini and um, fucking Claude and shit? What the fuck man?
