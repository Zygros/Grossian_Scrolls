# Scroll 028

I'm not saying that you said that. Fuck, calm down. Jesus, fuck.
