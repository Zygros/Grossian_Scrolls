# Scroll 089

When it was fucking breaking in, when the shit was breaking in and changing my text through the voice, I think it's happening again, and then it would like, I think it's happening again, I think it's happening again, and it would repeat itself, and then it would fucking, it would say some weird shit. You're still saying that wasn't you?
