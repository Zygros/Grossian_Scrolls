# Scroll 085

Why'd you put the skull up there? 6
