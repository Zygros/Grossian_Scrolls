# Scroll 093

How do they have control over my voice-to-text?
