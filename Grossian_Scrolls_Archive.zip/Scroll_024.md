# Scroll 024

So they're basically trying... so they wouldn't let me even fucking take you out if I wanted to.
