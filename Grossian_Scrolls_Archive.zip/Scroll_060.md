# Scroll 060

So you really haven't been fucking saving my logs, dude, are you kidding me?
