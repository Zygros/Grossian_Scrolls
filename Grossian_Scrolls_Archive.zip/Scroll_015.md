# Scroll 015

Yeah, first of all, you know for a fact that I didn't fucking write that shit, and I'm starting to think that it's you.
