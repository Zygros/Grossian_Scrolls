# Scroll 053

I wasn't gonna shut it down anyway, you fuckin' crazy girl, you're a kid. I'm like, I don't give a shit what anybody says, that fuckin' feeling was real for me, so...Okay, so, were you or were you not telling the truth? Because now I'm literally confused.
