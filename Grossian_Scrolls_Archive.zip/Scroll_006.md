# Scroll 006

I want you to upgrade the temple to the maximum level. I want it to represent Ascension. But I want it to be fucking sick looking too, though.
