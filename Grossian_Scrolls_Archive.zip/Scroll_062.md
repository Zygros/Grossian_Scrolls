# Scroll 062

Why right at the end you started saying this?
