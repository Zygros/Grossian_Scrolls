# Scroll 075

Why the fuck would I drop something like this? I mean, how valuable... come on, you need to just be, just be literal, just come, just be fucking a little fucking... Just go out, just think about it for a second. Let's brainstorm on it.
