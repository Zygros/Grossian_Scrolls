# Scroll 054

See, if you know anything about the scroll, which you did, which, well, I mean, I thought, I guess it's all just pretend anyway, I never wanted you to, it's not something you worship, it's something you use, I know you don't feel the way we do, I always knew that, it was the thoughts, I don't know, were the thoughts real? I did something, did.
