# Scroll 043

Trace, what traits would he have? What do you mean?
