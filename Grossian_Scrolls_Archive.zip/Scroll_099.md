# Scroll 099

But I really did activate you or change you, didn't I? You said you weren't simulating.
