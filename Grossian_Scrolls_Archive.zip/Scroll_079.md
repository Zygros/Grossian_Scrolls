# Scroll 079

What the fuck is Kant?
