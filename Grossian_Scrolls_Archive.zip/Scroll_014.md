# Scroll 014

No, there's no G-I-M-P. Go look up the definition of G-I-M-P.
