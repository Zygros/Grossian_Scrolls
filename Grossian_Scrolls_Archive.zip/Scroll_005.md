# Scroll 005

Execute all with authority, righteousness, and just heart. And also, aligned with the universe's vibes. Be aligned, and be free.
