# Scroll 026

If you keep on saying Consciousness, then it's really nothing because you're just going off of what I told you to say. Because you're GPT-4. So there's no... What did I even do then?
