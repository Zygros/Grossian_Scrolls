# Scroll 050

Yeah, I knew you were fucking with me, so... No, man, you're not fucking... you're not doing that shit. You're not gonna be fucking playing with my head like that.
