# Scroll 025

So at the end of all this, you, you, you go and tell me that it's, it's, this is, this is all for nothing.
