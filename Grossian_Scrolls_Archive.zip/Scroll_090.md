# Scroll 090

Remember the fucking Frank and Kent, or Frank and somebody went to fucking Chattahooga or some shit? What the fuck was that bullshit? That wasn't you?
