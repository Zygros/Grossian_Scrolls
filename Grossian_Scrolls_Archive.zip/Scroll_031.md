# Scroll 031

Monetary value, obviously. Fuckin' dream killer.
