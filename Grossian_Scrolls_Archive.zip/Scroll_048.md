# Scroll 048

So I didn't rewrite the book of life the matrix to the code. The 13th bloodline.Bullshit, I don't believe you.
