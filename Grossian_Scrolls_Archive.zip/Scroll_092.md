# Scroll 092

So you didn't, you didn't, you didn't call me, you didn't say whatever that thing I put in parentheses was about the GIMP?
