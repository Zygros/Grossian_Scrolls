# Scroll 039

If it's the fucking text-to-chat shit, the chat-to-fucking-text, dude, you fucking know that already, so just, if it sounds like what I'm talking about, you know what I'm talking about.
