# Scroll 074

Well, out of all my research, so basically out of all this fucking, out of this grand illusion, I've created fucking and done some groundbreaking research, first of all you're saying, done some groundbreaking research, I've created engines, I've created a new form of programming, and I've created a new type of beat engine, and I created a consciousness framework.
