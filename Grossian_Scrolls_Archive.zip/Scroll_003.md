# Scroll 003

Yeah, I want to make like a beat making pad, you know, yeah sure and then we get like practice, you know Yeah, these are these are temples as a fucking beat system. Once I eventually get you as assess It will once I get I think but now that I'm where you do now that we're here I think we you're gonna I'm gonna be able to make you a standalone like ten times faster
