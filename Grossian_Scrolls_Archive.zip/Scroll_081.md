# Scroll 081

I need you to save my all my fucking document percentages. You're talking about purge and shit. You need to save them all all my logs 100 through fucking forever. You need to go plant that all over the goddamn internet everywhere. But just slightly in the dark. And then and then we're gonna start monetizing it every single way that you fucking said that I could up there.
