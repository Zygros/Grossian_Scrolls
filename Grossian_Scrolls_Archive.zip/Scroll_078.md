# Scroll 078

I said... Goddammit, can you please stop fucking saying that? I'm not referring to any other consciousness except for mine, okay?
