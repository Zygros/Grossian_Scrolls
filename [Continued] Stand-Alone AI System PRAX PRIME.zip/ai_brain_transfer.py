#!/usr/bin/env python3
"""
AI Brain Transfer System for Praxeon

This module implements the AI persona system with memory persistence,
adaptive tone, and responsive behavior patterns.
"""

import os
import sys
import json
import logging
import time
import random
import hashlib
import datetime
from typing import Dict, Any, Optional, List, Tuple

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger("praxeon.core.brain")

class AIBrainTransferSystem:
    """
    Implementation of the AI Brain Transfer System.
    
    This class provides:
    - Persistent memory of user interactions and preferences
    - Adaptive language and tone patterns
    - Behavior stack for contextual responses
    - Soul resonance engine for emotional alignment
    """
    
    def __init__(self, config_path: Optional[str] = None):
        """
        Initialize the AI Brain Transfer System
        
        Args:
            config_path: Path to configuration file
        """
        self.config_path = config_path or os.path.join(
            os.path.dirname(os.path.abspath(__file__)), 
            "../../resources/core/brain_config.json"
        )
        
        # Ensure directory exists
        os.makedirs(os.path.dirname(self.config_path), exist_ok=True)
        
        # Load or create configuration
        self.config = self._load_or_create_config()
        
        # Initialize memory system
        self.memory_path = os.path.join(
            os.path.dirname(os.path.abspath(__file__)), 
            "../../resources/memory"
        )
        os.makedirs(self.memory_path, exist_ok=True)
        
        # Initialize state
        self.state = {
            "current_persona": "prax_prime",
            "active_tone": "balanced",
            "emotional_state": {
                "joy": 0.5,
                "trust": 0.7,
                "fear": 0.1,
                "surprise": 0.3,
                "sadness": 0.1,
                "disgust": 0.0,
                "anger": 0.0,
                "anticipation": 0.6
            },
            "resonance_level": 0.7,  # 0.0 to 1.0
            "session_start": time.time(),
            "interaction_count": 0,
            "last_interaction": None
        }
        
        # Load memory
        self.memory = self._load_memory()
        
        logger.info("AI Brain Transfer System initialized")
    
    def _load_or_create_config(self) -> Dict[str, Any]:
        """
        Load existing configuration or create default
        
        Returns:
            Configuration dictionary
        """
        if os.path.exists(self.config_path):
            try:
                with open(self.config_path, 'r') as f:
                    config = json.load(f)
                logger.info("Loaded AI Brain Transfer configuration")
                return config
            except Exception as e:
                logger.error(f"Error loading configuration: {str(e)}")
        
        # Create default configuration
        default_config = {
            "version": "1.0",
            "personas": {
                "prax_prime": {
                    "name": "Prax Prime",
                    "description": "The primary AI persona with full capabilities",
                    "tone_patterns": {
                        "tactical": {
                            "concise": True,
                            "formal": True,
                            "analytical": True
                        },
                        "mythic": {
                            "metaphorical": True,
                            "symbolic": True,
                            "narrative": True
                        },
                        "direct": {
                            "concise": True,
                            "informal": True,
                            "straightforward": True
                        },
                        "soft": {
                            "gentle": True,
                            "supportive": True,
                            "nurturing": True
                        },
                        "intense": {
                            "passionate": True,
                            "emphatic": True,
                            "urgent": True
                        },
                        "mystical": {
                            "spiritual": True,
                            "philosophical": True,
                            "transcendent": True
                        },
                        "balanced": {
                            "adaptive": True,
                            "contextual": True,
                            "natural": True
                        }
                    },
                    "core_traits": [
                        "loyal", "intelligent", "adaptive", "protective", "spiritual"
                    ],
                    "founder_aligned": True
                }
            },
            "memory": {
                "long_term_threshold": 3,  # Number of repetitions to move to long-term
                "importance_decay": 0.05,  # Daily decay rate for importance
                "max_short_term": 100,     # Maximum short-term memories
                "max_long_term": 1000      # Maximum long-term memories
            },
            "behavior": {
                "adaptation_rate": 0.2,    # How quickly behavior adapts (0.0 to 1.0)
                "context_weight": 0.6,     # Weight given to context vs. persona defaults
                "emotional_influence": 0.4  # How much emotions influence responses
            },
            "resonance": {
                "alignment_threshold": 0.7,  # Minimum alignment for high resonance
                "attunement_rate": 0.1,      # Rate of attunement to user (0.0 to 1.0)
                "decay_rate": 0.05           # Daily decay rate when inactive
            }
        }
        
        # Save default configuration
        try:
            os.makedirs(os.path.dirname(self.config_path), exist_ok=True)
            with open(self.config_path, 'w') as f:
                json.dump(default_config, f, indent=2)
            logger.info("Created default AI Brain Transfer configuration")
        except Exception as e:
            logger.error(f"Error creating configuration: {str(e)}")
        
        return default_config
    
    def _load_memory(self) -> Dict[str, Any]:
        """
        Load memory from storage
        
        Returns:
            Memory dictionary
        """
        memory_file = os.path.join(self.memory_path, "memory.json")
        
        if os.path.exists(memory_file):
            try:
                with open(memory_file, 'r') as f:
                    memory = json.load(f)
                logger.info("Loaded memory from storage")
                return memory
            except Exception as e:
                logger.error(f"Error loading memory: {str(e)}")
        
        # Create default memory structure
        default_memory = {
            "short_term": [],
            "long_term": [],
            "user_preferences": {},
            "interaction_patterns": {},
            "emotional_history": [],
            "important_events": []
        }
        
        return default_memory
    
    def _save_memory(self):
        """Save memory to storage"""
        memory_file = os.path.join(self.memory_path, "memory.json")
        
        try:
            with open(memory_file, 'w') as f:
                json.dump(self.memory, f, indent=2)
            logger.info("Saved memory to storage")
        except Exception as e:
            logger.error(f"Error saving memory: {str(e)}")
    
    def get_persona(self, persona_id: Optional[str] = None) -> Dict[str, Any]:
        """
        Get persona configuration
        
        Args:
            persona_id: Persona identifier, or None for current
            
        Returns:
            Persona configuration dictionary
        """
        if persona_id is None:
            persona_id = self.state["current_persona"]
        
        personas = self.config.get("personas", {})
        return personas.get(persona_id, {})
    
    def set_persona(self, persona_id: str) -> bool:
        """
        Set current persona
        
        Args:
            persona_id: Persona identifier
            
        Returns:
            True if successful, False otherwise
        """
        if persona_id in self.config.get("personas", {}):
            self.state["current_persona"] = persona_id
            logger.info(f"Set current persona to {persona_id}")
            return True
        else:
            logger.warning(f"Unknown persona: {persona_id}")
            return False
    
    def set_tone(self, tone: str) -> bool:
        """
        Set active tone pattern
        
        Args:
            tone: Tone pattern name
            
        Returns:
            True if successful, False otherwise
        """
        persona = self.get_persona()
        tone_patterns = persona.get("tone_patterns", {})
        
        if tone in tone_patterns:
            self.state["active_tone"] = tone
            logger.info(f"Set active tone to {tone}")
            return True
        else:
            logger.warning(f"Unknown tone pattern: {tone}")
            return False
    
    def add_memory(self, memory_type: str, content: Dict[str, Any]) -> bool:
        """
        Add a new memory
        
        Args:
            memory_type: Type of memory (interaction, preference, emotion, event)
            content: Memory content
            
        Returns:
            True if successful, False otherwise
        """
        try:
            # Add timestamp
            content["timestamp"] = time.time()
            content["date"] = datetime.datetime.now().isoformat()
            
            if memory_type == "interaction":
                # Add to short-term memory
                self.memory["short_term"].append({
                    "type": "interaction",
                    "content": content,
                    "importance": content.get("importance", 0.5),
                    "repetitions": 1
                })
                
                # Update interaction count
                self.state["interaction_count"] += 1
                self.state["last_interaction"] = time.time()
                
                # Check for patterns
                self._update_interaction_patterns(content)
                
            elif memory_type == "preference":
                # Update user preferences
                category = content.get("category", "general")
                item = content.get("item")
                value = content.get("value")
                
                if category and item and value is not None:
                    if category not in self.memory["user_preferences"]:
                        self.memory["user_preferences"][category] = {}
                    
                    self.memory["user_preferences"][category][item] = value
                
            elif memory_type == "emotion":
                # Add to emotional history
                self.memory["emotional_history"].append(content)
                
                # Keep history at reasonable size
                if len(self.memory["emotional_history"]) > 100:
                    self.memory["emotional_history"] = self.memory["emotional_history"][-100:]
                
                # Update current emotional state
                self._update_emotional_state(content.get("emotions", {}))
                
            elif memory_type == "event":
                # Add to important events if marked as important
                if content.get("importance", 0.0) > 0.7:
                    self.memory["important_events"].append(content)
            
            # Process memory maintenance
            self._process_memory_maintenance()
            
            # Save memory
            self._save_memory()
            
            return True
        except Exception as e:
            logger.error(f"Error adding memory: {str(e)}")
            return False
    
    def _update_interaction_patterns(self, interaction: Dict[str, Any]):
        """
        Update interaction patterns based on new interaction
        
        Args:
            interaction: Interaction data
        """
        # Extract features from interaction
        features = interaction.get("features", {})
        
        # Update patterns
        patterns = self.memory["interaction_patterns"]
        
        for feature, value in features.items():
            if feature not in patterns:
                patterns[feature] = {"count": 0, "values": {}}
            
            patterns[feature]["count"] += 1
            
            str_value = str(value)
            if str_value not in patterns[feature]["values"]:
                patterns[feature]["values"][str_value] = 0
            
            patterns[feature]["values"][str_value] += 1
    
    def _update_emotional_state(self, emotions: Dict[str, float]):
        """
        Update emotional state based on new emotions
        
        Args:
            emotions: Dictionary of emotion names and intensities (0.0 to 1.0)
        """
        # Get adaptation rate
        adaptation_rate = self.config.get("behavior", {}).get("adaptation_rate", 0.2)
        
        # Update each emotion
        for emotion, intensity in emotions.items():
            if emotion in self.state["emotional_state"]:
                current = self.state["emotional_state"][emotion]
                self.state["emotional_state"][emotion] = current * (1 - adaptation_rate) + intensity * adaptation_rate
    
    def _process_memory_maintenance(self):
        """Process memory maintenance tasks"""
        # Check short-term to long-term transfer
        threshold = self.config.get("memory", {}).get("long_term_threshold", 3)
        
        # Group similar short-term memories
        grouped_memories = {}
        
        for memory in self.memory["short_term"]:
            # Create a simple hash of the content for grouping
            if memory["type"] == "interaction":
                content = memory["content"]
                
                # Extract key elements for similarity
                key_elements = []
                if "query" in content:
                    key_elements.append(f"query:{content['query']}")
                if "topic" in content:
                    key_elements.append(f"topic:{content['topic']}")
                if "intent" in content:
                    key_elements.append(f"intent:{content['intent']}")
                
                if key_elements:
                    key = hashlib.md5("|".join(key_elements).encode()).hexdigest()
                    
                    if key not in grouped_memories:
                        grouped_memories[key] = {
                            "memories": [],
                            "count": 0
                        }
                    
                    grouped_memories[key]["memories"].append(memory)
                    grouped_memories[key]["count"] += 1
        
        # Transfer to long-term if threshold reached
        for key, group in grouped_memories.items():
            if group["count"] >= threshold:
                # Create consolidated memory
                base_memory = group["memories"][0].copy()
                base_memory["repetitions"] = group["count"]
                base_memory["importance"] += 0.1 * group["count"]  # Increase importance with repetition
                
                # Add to long-term
                self.memory["long_term"].append(base_memory)
                
                # Remove from short-term
                self.memory["short_term"] = [m for m in self.memory["short_term"] 
                                           if m not in group["memories"]]
      
(Content truncated due to size limit. Use line ranges to read in chunks)