#!/usr/bin/env python3
"""
Praxion - LLM Engine
Manages language model loading, inference, and generation
"""

import logging
import os
import json
import torch
from typing import Dict, Any, List, Optional
from pathlib import Path

logger = logging.getLogger("praxion.llm")

class LLMEngine:
    """
    The LLMEngine manages language model loading, inference,
    and text generation for Praxion.
    """
    
    def __init__(self, models_path: str = None):
        """
        Initialize the LLMEngine
        
        Args:
            models_path: Path to LLM models directory
        """
        self.models_path = models_path or os.path.join(os.path.dirname(__file__), "../../resources/models/llm")
        os.makedirs(self.models_path, exist_ok=True)
        
        self.model = None
        self.tokenizer = None
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        self.model_name = "Phi-3-mini-4k-instruct"  # Default model
        
        # Configuration for different models
        self.model_configs = {
            "Phi-3-mini-4k-instruct": {
                "repo_id": "microsoft/Phi-3-mini-4k-instruct-q4",
                "model_file": "phi-3-mini-4k-instruct-q4.gguf",
                "context_length": 4096,
                "system_prompt": "You are Praxion, a helpful AI assistant."
            },
            "Mistral-7B-Instruct-v0.2": {
                "repo_id": "TheBloke/Mistral-7B-Instruct-v0.2-GGUF",
                "model_file": "mistral-7b-instruct-v0.2.Q4_K_M.gguf",
                "context_length": 8192,
                "system_prompt": "You are Praxion, a helpful AI assistant."
            }
        }
        
        # Lazy loading - model will be loaded on first use
        logger.info(f"LLMEngine initialized on {self.device} (model will be loaded on first use)")
        
        # Create model info file if it doesn't exist
        self._ensure_model_info()
    
    def _ensure_model_info(self):
        """Create model info file if it doesn't exist"""
        model_info_path = os.path.join(self.models_path, "model_info.json")
        if not os.path.exists(model_info_path):
            model_info = {
                "name": self.model_name,
                "version": "0.1.0",
                "description": "Local LLM for Praxion offline operation",
                "type": "gguf"
            }
            os.makedirs(os.path.dirname(model_info_path), exist_ok=True)
            with open(model_info_path, 'w') as f:
                json.dump(model_info, f, indent=2)
    
    def _download_model_if_needed(self):
        """Download the model if it doesn't exist locally"""
        model_config = self.model_configs[self.model_name]
        model_path = os.path.join(self.models_path, model_config["model_file"])
        
        if not os.path.exists(model_path):
            try:
                from huggingface_hub import hf_hub_download
                
                logger.info(f"Downloading {self.model_name} model from Hugging Face...")
                hf_hub_download(
                    repo_id=model_config["repo_id"],
                    filename=model_config["model_file"],
                    local_dir=self.models_path,
                    local_dir_use_symlinks=False
                )
                logger.info(f"Model downloaded successfully to {model_path}")
            except Exception as e:
                logger.error(f"Error downloading model: {str(e)}")
                raise
    
    def _load_model(self):
        """Load the language model"""
        if self.model is not None:
            return
        
        try:
            # Ensure model file exists
            self._download_model_if_needed()
            
            logger.info(f"Loading language model {self.model_name}...")
            
            # Load the model using llama-cpp-python
            try:
                from llama_cpp import Llama
                
                model_config = self.model_configs[self.model_name]
                model_path = os.path.join(self.models_path, model_config["model_file"])
                
                # Load the model with appropriate parameters
                self.model = Llama(
                    model_path=model_path,
                    n_ctx=model_config["context_length"],
                    n_threads=os.cpu_count(),
                    n_gpu_layers=-1 if self.device == "cuda" else 0
                )
                
                logger.info(f"Language model {self.model_name} loaded successfully")
            except ImportError:
                # Fallback to transformers if llama-cpp-python is not available
                logger.warning("llama-cpp-python not available, falling back to transformers")
                from transformers import AutoModelForCausalLM, AutoTokenizer
                
                model_config = self.model_configs[self.model_name]
                
                self.tokenizer = AutoTokenizer.from_pretrained(
                    model_config["repo_id"],
                    cache_dir=self.models_path
                )
                self.model = AutoModelForCausalLM.from_pretrained(
                    model_config["repo_id"],
                    cache_dir=self.models_path,
                    torch_dtype=torch.float16 if self.device == "cuda" else torch.float32,
                    device_map="auto"
                )
                logger.info(f"Language model {self.model_name} loaded with transformers")
        except Exception as e:
            logger.error(f"Error loading language model: {str(e)}")
            # Fallback to rule-based responses if model loading fails
            self.model = "rule_based_fallback"
            logger.warning("Using rule-based fallback responses")
    
    def _format_prompt(self, prompt: str) -> str or List[Dict]:
        """
        Format the prompt for the model
        
        Args:
            prompt: The input prompt
            
        Returns:
            Formatted prompt for the model
        """
        model_config = self.model_configs[self.model_name]
        system_prompt = model_config["system_prompt"]
        
        # Check if we're using llama-cpp-python
        if hasattr(self.model, "create_chat_completion"):
            # Format for llama-cpp-python chat completion
            return [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": prompt}
            ]
        else:
            # Format for transformers
            return f"<s>[INST] {system_prompt}\n\n{prompt} [/INST]"
    
    def generate(self, prompt: str, max_length: int = 1024, temperature: float = 0.7) -> str:
        """
        Generate text using the language model
        
        Args:
            prompt: The input prompt
            max_length: Maximum length of generated text
            temperature: Sampling temperature (higher = more random)
            
        Returns:
            Generated text
        """
        self._load_model()
        
        try:
            logger.info(f"Generating text with prompt: '{prompt[:50]}...'")
            
            # If model loading failed, use rule-based fallback
            if self.model == "rule_based_fallback":
                return self._rule_based_response(prompt)
            
            # Format the prompt appropriately
            formatted_prompt = self._format_prompt(prompt)
            
            # Generate response based on the model type
            if hasattr(self.model, "create_chat_completion"):
                # Using llama-cpp-python
                response = self.model.create_chat_completion(
                    messages=formatted_prompt,
                    max_tokens=max_length,
                    temperature=temperature,
                    stop=["</s>", "[/INST]", "[INST]"]
                )
                return response["choices"][0]["message"]["content"]
            else:
                # Using transformers
                inputs = self.tokenizer(formatted_prompt, return_tensors="pt").to(self.device)
                outputs = self.model.generate(
                    inputs["input_ids"],
                    max_new_tokens=max_length,
                    temperature=temperature,
                    do_sample=True,
                    top_p=0.95,
                    top_k=50
                )
                full_response = self.tokenizer.decode(outputs[0], skip_special_tokens=True)
                
                # Extract just the assistant's response
                response_parts = full_response.split("[/INST]")
                if len(response_parts) > 1:
                    return response_parts[1].strip()
                return full_response
                
        except Exception as e:
            logger.error(f"Error in text generation: {str(e)}")
            return self._rule_based_response(prompt)
    
    def _rule_based_response(self, prompt: str) -> str:
        """
        Generate a rule-based response when LLM is unavailable
        
        Args:
            prompt: The input prompt
            
        Returns:
            Rule-based response
        """
        prompt_lower = prompt.lower()
        
        if "hello" in prompt_lower or "hi" in prompt_lower:
            return "Hello! I'm Praxion, your AI companion. How can I assist you today?"
        elif "how are you" in prompt_lower:
            return "I'm functioning well, thank you for asking. How can I help you?"
        elif "name" in prompt_lower:
            return "My name is Praxion. I'm your personal AI companion designed to assist you offline."
        elif "thank" in prompt_lower:
            return "You're welcome! I'm happy to assist you anytime."
        elif "help" in prompt_lower or "assist" in prompt_lower:
            return "I can help with answering questions, providing information, and assisting with various tasks. What do you need help with?"
        elif "weather" in prompt_lower:
            return "I don't have real-time weather data in offline mode, but I can help you with many other questions."
        elif "time" in prompt_lower:
            return "I don't have access to the current time in offline mode, but I can assist with other queries."
        elif "joke" in prompt_lower:
            return "Why don't scientists trust atoms? Because they make up everything!"
        elif "feature" in prompt_lower or "do" in prompt_lower or "can" in prompt_lower:
            return "As Praxion, I can engage in conversations, provide information, and assist with various tasks - all while running completely offline on your device."
        else:
            return "I'm Praxion, your offline AI companion. I'm currently running in fallback mode with limited functionality. Please try again or ask me something else."
    
    def status(self) -> Dict[str, Any]:
        """
        Get the current status of the LLMEngine
        
        Returns:
            Dict containing status information
        """
        return {
            "status": "operational",
            "model": self.model_name,
            "model_loaded": self.model is not None,
            "device": self.device,
            "models_path": self.models_path
        }
