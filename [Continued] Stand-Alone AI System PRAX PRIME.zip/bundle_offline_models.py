#!/usr/bin/env python3
"""
Praxion - Model and Asset Bundler
Downloads and prepares offline models and assets for Praxion
"""

import os
import sys
import logging
import argparse
import subprocess
import json
import shutil
import tarfile
import requests
from pathlib import Path
from tqdm import tqdm

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger("praxion.bundler")

# Define paths
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
ROOT_DIR = os.path.abspath(os.path.join(SCRIPT_DIR, ".."))
RESOURCES_DIR = os.path.join(ROOT_DIR, "resources")
MODELS_DIR = os.path.join(RESOURCES_DIR, "models")
ASSETS_DIR = os.path.join(RESOURCES_DIR, "assets")
CACHE_DIR = os.path.join(RESOURCES_DIR, "cache")

# Define model URLs and versions
MODELS = {
    "llm": {
        "name": "phi-2",
        "url": "https://huggingface.co/microsoft/phi-2/resolve/main/pytorch_model.bin",
        "config_url": "https://huggingface.co/microsoft/phi-2/resolve/main/config.json",
        "tokenizer_url": "https://huggingface.co/microsoft/phi-2/resolve/main/tokenizer.json",
        "size_mb": 2500
    },
    "whisper": {
        "name": "whisper-small",
        "url": "https://openaipublic.azureedge.net/main/whisper/models/9ecf779972d90ba49c06d968637d720dd632c55bbf19d441fb42bf17a411e794/small.pt",
        "size_mb": 461
    },
    "tts": {
        "name": "piper-tts",
        "url": "https://huggingface.co/rhasspy/piper-voices/resolve/main/en/en_US/lessac/medium/en_US-lessac-medium.onnx",
        "config_url": "https://huggingface.co/rhasspy/piper-voices/resolve/main/en/en_US/lessac/medium/en_US-lessac-medium.onnx.json",
        "size_mb": 50
    }
}

def create_directories():
    """Create necessary directories"""
    os.makedirs(RESOURCES_DIR, exist_ok=True)
    os.makedirs(MODELS_DIR, exist_ok=True)
    os.makedirs(ASSETS_DIR, exist_ok=True)
    os.makedirs(CACHE_DIR, exist_ok=True)
    
    # Create subdirectories for each model
    for model_key in MODELS:
        os.makedirs(os.path.join(MODELS_DIR, model_key), exist_ok=True)
    
    logger.info("Created directory structure")

def download_file(url, dest_path, desc=None):
    """
    Download a file with progress bar
    
    Args:
        url: URL to download
        dest_path: Destination path
        desc: Description for progress bar
    
    Returns:
        True if successful, False otherwise
    """
    try:
        response = requests.get(url, stream=True)
        response.raise_for_status()
        
        total_size = int(response.headers.get('content-length', 0))
        block_size = 1024  # 1 KB
        
        with open(dest_path, 'wb') as f, tqdm(
            desc=desc,
            total=total_size,
            unit='B',
            unit_scale=True,
            unit_divisor=1024,
        ) as pbar:
            for data in response.iter_content(block_size):
                f.write(data)
                pbar.update(len(data))
        
        return True
    except Exception as e:
        logger.error(f"Error downloading {url}: {str(e)}")
        return False

def download_models(force=False):
    """
    Download all required models
    
    Args:
        force: Force download even if files exist
    
    Returns:
        True if all downloads successful, False otherwise
    """
    success = True
    
    for model_key, model_info in MODELS.items():
        model_dir = os.path.join(MODELS_DIR, model_key)
        model_path = os.path.join(model_dir, os.path.basename(model_info["url"]))
        
        # Skip if file exists and not forcing download
        if os.path.exists(model_path) and not force:
            logger.info(f"Model {model_info['name']} already exists, skipping")
            continue
        
        # Download model
        logger.info(f"Downloading {model_info['name']} ({model_info['size_mb']} MB)...")
        if not download_file(model_info["url"], model_path, f"Downloading {model_info['name']}"):
            success = False
        
        # Download additional files if needed
        if "config_url" in model_info:
            config_path = os.path.join(model_dir, os.path.basename(model_info["config_url"]))
            if not os.path.exists(config_path) or force:
                if not download_file(model_info["config_url"], config_path, f"Downloading {model_info['name']} config"):
                    success = False
        
        if "tokenizer_url" in model_info:
            tokenizer_path = os.path.join(model_dir, os.path.basename(model_info["tokenizer_url"]))
            if not os.path.exists(tokenizer_path) or force:
                if not download_file(model_info["tokenizer_url"], tokenizer_path, f"Downloading {model_info['name']} tokenizer"):
                    success = False
    
    return success

def download_assets():
    """
    Download and prepare UI assets
    
    Returns:
        True if successful, False otherwise
    """
    try:
        # Create UI assets directory
        ui_assets_dir = os.path.join(ASSETS_DIR, "ui")
        os.makedirs(ui_assets_dir, exist_ok=True)
        
        # Copy UI assets from src/ui
        desktop_assets_src = os.path.join(ROOT_DIR, "src", "ui", "desktop", "public")
        desktop_assets_dest = os.path.join(ui_assets_dir, "desktop")
        
        if os.path.exists(desktop_assets_src):
            if os.path.exists(desktop_assets_dest):
                shutil.rmtree(desktop_assets_dest)
            shutil.copytree(desktop_assets_src, desktop_assets_dest)
            logger.info("Copied desktop UI assets")
        else:
            logger.warning("Desktop UI assets not found")
        
        # Create default persona icons
        icons_dir = os.path.join(ASSETS_DIR, "icons")
        os.makedirs(icons_dir, exist_ok=True)
        
        # Create sound assets directory
        sounds_dir = os.path.join(ASSETS_DIR, "sounds")
        os.makedirs(sounds_dir, exist_ok=True)
        
        return True
    except Exception as e:
        logger.error(f"Error preparing assets: {str(e)}")
        return False

def create_model_config():
    """
    Create model configuration file
    
    Returns:
        True if successful, False otherwise
    """
    try:
        config = {
            "version": "0.1.0",
            "models": {
                "llm": {
                    "name": MODELS["llm"]["name"],
                    "path": os.path.join("models", "llm", os.path.basename(MODELS["llm"]["url"])),
                    "config_path": os.path.join("models", "llm", os.path.basename(MODELS["llm"]["config_url"])),
                    "tokenizer_path": os.path.join("models", "llm", os.path.basename(MODELS["llm"]["tokenizer_url"])),
                    "type": "phi-2",
                    "offline_capable": True
                },
                "whisper": {
                    "name": MODELS["whisper"]["name"],
                    "path": os.path.join("models", "whisper", os.path.basename(MODELS["whisper"]["url"])),
                    "type": "whisper",
                    "offline_capable": True
                },
                "tts": {
                    "name": MODELS["tts"]["name"],
                    "path": os.path.join("models", "tts", os.path.basename(MODELS["tts"]["url"])),
                    "config_path": os.path.join("models", "tts", os.path.basename(MODELS["tts"]["config_url"])),
                    "type": "piper",
                    "offline_capable": True
                }
            },
            "assets": {
                "ui": {
                    "desktop": "assets/ui/desktop",
                    "mobile": "assets/ui/mobile"
                },
                "icons": "assets/icons",
                "sounds": "assets/sounds"
            },
            "cache": {
                "path": "cache",
                "max_size_mb": 1000
            }
        }
        
        config_path = os.path.join(RESOURCES_DIR, "model_config.json")
        with open(config_path, 'w') as f:
            json.dump(config, f, indent=2)
        
        logger.info(f"Created model configuration at {config_path}")
        return True
    except Exception as e:
        logger.error(f"Error creating model configuration: {str(e)}")
        return False

def create_offline_bundle():
    """
    Create offline bundle archive
    
    Returns:
        Path to archive if successful, None otherwise
    """
    try:
        bundle_path = os.path.join(ROOT_DIR, "praxion_offline_bundle.tar.gz")
        
        with tarfile.open(bundle_path, "w:gz") as tar:
            tar.add(RESOURCES_DIR, arcname=os.path.basename(RESOURCES_DIR))
        
        logger.info(f"Created offline bundle at {bundle_path}")
        return bundle_path
    except Exception as e:
        logger.error(f"Error creating offline bundle: {str(e)}")
        return None

def verify_bundle():
    """
    Verify that all required files are present
    
    Returns:
        True if all files present, False otherwise
    """
    all_present = True
    
    # Check model files
    for model_key, model_info in MODELS.items():
        model_path = os.path.join(MODELS_DIR, model_key, os.path.basename(model_info["url"]))
        if not os.path.exists(model_path):
            logger.error(f"Missing model file: {model_path}")
            all_present = False
        
        if "config_url" in model_info:
            config_path = os.path.join(MODELS_DIR, model_key, os.path.basename(model_info["config_url"]))
            if not os.path.exists(config_path):
                logger.error(f"Missing config file: {config_path}")
                all_present = False
        
        if "tokenizer_url" in model_info:
            tokenizer_path = os.path.join(MODELS_DIR, model_key, os.path.basename(model_info["tokenizer_url"]))
            if not os.path.exists(tokenizer_path):
                logger.error(f"Missing tokenizer file: {tokenizer_path}")
                all_present = False
    
    # Check configuration file
    config_path = os.path.join(RESOURCES_DIR, "model_config.json")
    if not os.path.exists(config_path):
        logger.error(f"Missing configuration file: {config_path}")
        all_present = False
    
    return all_present

def main():
    parser = argparse.ArgumentParser(description="Praxion Model and Asset Bundler")
    parser.add_argument("--force", action="store_true", help="Force download even if files exist")
    parser.add_argument("--verify", action="store_true", help="Verify bundle without downloading")
    args = parser.parse_args()
    
    if args.verify:
        logger.info("Verifying bundle...")
        if verify_bundle():
            logger.info("Bundle verification successful")
            return 0
        else:
            logger.error("Bundle verification failed")
            return 1
    
    logger.info("Starting Praxion model and asset bundling")
    
    # Create directories
    create_directories()
    
    # Download models
    if not download_models(args.force):
        logger.error("Failed to download all models")
        return 1
    
    # Download assets
    if not download_assets():
        logger.error("Failed to prepare assets")
        return 1
    
    # Create model configuration
    if not create_model_config():
        logger.error("Failed to create model configuration")
        return 1
    
    # Verify bundle
    if not verify_bundle():
        logger.error("Bundle verification failed")
        return 1
    
    # Create offline bundle
    bundle_path = create_offline_bundle()
    if not bundle_path:
        logger.error("Failed to create offline bundle")
        return 1
    
    logger.info("Praxion model and asset bundling completed successfully")
    return 0

if __name__ == "__main__":
    sys.exit(main())
