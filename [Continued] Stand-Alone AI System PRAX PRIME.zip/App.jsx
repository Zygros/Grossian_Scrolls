import React, { useState, useEffect, useRef } from 'react';
import './App.css';
import axios from 'axios';
import Header from './components/Header';
import ChatMessage from './components/ChatMessage';
import ChatInput from './components/ChatInput';
import VoiceControl from './components/VoiceControl';
import Sidebar from './components/Sidebar';
import PersonaModal from './components/PersonaModal';
import SessionList from './components/SessionList';
import LoginModal from './components/LoginModal';
import SettingsModal from './components/SettingsModal';

function App() {
  // State for UI
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [welcomeMessage, setWelcomeMessage] = useState('Loading...');
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  const messagesEndRef = useRef(null);
  
  // State for persona management
  const [showPersonaModal, setShowPersonaModal] = useState(false);
  const [showLoginModal, setShowLoginModal] = useState(false);
  const [showSettingsModal, setShowSettingsModal] = useState(false);
  const [personas, setPersonas] = useState([]);
  const [currentPersona, setCurrentPersona] = useState(null);
  const [authToken, setAuthToken] = useState(localStorage.getItem('praxion_auth_token'));
  
  // State for session management
  const [sessions, setSessions] = useState([]);
  const [currentSessionId, setCurrentSessionId] = useState(null);
  const [sessionTitle, setSessionTitle] = useState('New Conversation');
  
  // Audio player reference
  const audioRef = useRef(new Audio());

  // Scroll to bottom of messages
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // Initialize app
  useEffect(() => {
    // Fetch welcome message
    fetchWelcomeMessage();
    
    // Check if user is already logged in
    if (authToken) {
      fetchCurrentPersona();
    }
    
    // Set up audio player
    audioRef.current.onended = () => {
      setIsPlayingAudio(false);
    };
    
    return () => {
      // Clean up audio player
      audioRef.current.pause();
      audioRef.current.src = '';
    };
  }, []);

  // Fetch welcome message
  const fetchWelcomeMessage = async () => {
    try {
      const res = await axios.get('http://localhost:8000/');
      setWelcomeMessage(res.data.message);
    } catch (err) {
      console.error('Error fetching welcome message:', err);
      setWelcomeMessage('Error connecting to Praxion backend');
    }
  };

  // Fetch current persona
  const fetchCurrentPersona = async () => {
    try {
      const res = await axios.get('http://localhost:8000/personas/current', {
        headers: { Authorization: `Bearer ${authToken}` }
      });
      setCurrentPersona(res.data);
      
      // Fetch sessions for this persona
      fetchSessions(res.data.id);
    } catch (err) {
      console.error('Error fetching current persona:', err);
      // Clear token if invalid
      if (err.response && err.response.status === 401) {
        localStorage.removeItem('praxion_auth_token');
        setAuthToken(null);
        setCurrentPersona(null);
      }
    }
  };

  // Fetch all personas
  const fetchPersonas = async () => {
    try {
      const res = await axios.get('http://localhost:8000/personas');
      setPersonas(res.data);
    } catch (err) {
      console.error('Error fetching personas:', err);
    }
  };

  // Fetch sessions for a persona
  const fetchSessions = async (personaId) => {
    try {
      const res = await axios.get(`http://localhost:8000/sessions?persona_id=${personaId}`);
      setSessions(res.data);
      
      // If no current session, create a new one
      if (!currentSessionId && res.data.length === 0) {
        createNewSession();
      } else if (res.data.length > 0 && !currentSessionId) {
        // Load the most recent session
        loadSession(res.data[0].id);
      }
    } catch (err) {
      console.error('Error fetching sessions:', err);
    }
  };

  // Create a new session
  const createNewSession = async () => {
    try {
      const res = await axios.post('http://localhost:8000/sessions', 
        { title: 'New Conversation' },
        { headers: { Authorization: `Bearer ${authToken}` } }
      );
      setCurrentSessionId(res.data.session_id);
      setSessionTitle('New Conversation');
      setMessages([]);
      
      // Refresh sessions list
      if (currentPersona) {
        fetchSessions(currentPersona.id);
      }
    } catch (err) {
      console.error('Error creating new session:', err);
    }
  };

  // Load a session
  const loadSession = async (sessionId) => {
    try {
      // Get session details
      const sessionRes = await axios.get(`http://localhost:8000/sessions/${sessionId}`);
      setCurrentSessionId(sessionId);
      setSessionTitle(sessionRes.data.title);
      
      // Get messages
      const messagesRes = await axios.get(`http://localhost:8000/sessions/${sessionId}/messages`);
      
      // Format messages for display
      const formattedMessages = messagesRes.data.messages.map(msg => ({
        text: msg.content,
        isUser: msg.role === 'user'
      }));
      
      setMessages(formattedMessages);
    } catch (err) {
      console.error('Error loading session:', err);
    }
  };

  // Update session title
  const updateSessionTitle = async (title) => {
    if (!currentSessionId) return;
    
    try {
      await axios.put(
        `http://localhost:8000/sessions/${currentSessionId}/title?title=${encodeURIComponent(title)}`,
        {},
        { headers: { Authorization: `Bearer ${authToken}` } }
      );
      setSessionTitle(title);
      
      // Refresh sessions list
      if (currentPersona) {
        fetchSessions(currentPersona.id);
      }
    } catch (err) {
      console.error('Error updating session title:', err);
    }
  };

  // Delete a session
  const deleteSession = async (sessionId) => {
    try {
      await axios.delete(
        `http://localhost:8000/sessions/${sessionId}`,
        { headers: { Authorization: `Bearer ${authToken}` } }
      );
      
      // If deleted current session, create a new one
      if (sessionId === currentSessionId) {
        createNewSession();
      }
      
      // Refresh sessions list
      if (currentPersona) {
        fetchSessions(currentPersona.id);
      }
    } catch (err) {
      console.error('Error deleting session:', err);
    }
  };

  // Login to a persona
  const handleLogin = async (personaId, password) => {
    try {
      const res = await axios.post(
        `http://localhost:8000/personas/login?persona_id=${personaId}${password ? `&password=${encodeURIComponent(password)}` : ''}`
      );
      
      // Save token and fetch persona details
      setAuthToken(res.data.token);
      localStorage.setItem('praxion_auth_token', res.data.token);
      
      // Close login modal
      setShowLoginModal(false);
      
      // Fetch current persona
      fetchCurrentPersona();
    } catch (err) {
      console.error('Error logging in:', err);
      alert('Login failed. Please check your credentials and try again.');
    }
  };

  // Logout
  const handleLogout = async () => {
    try {
      if (authToken) {
        await axios.post(
          'http://localhost:8000/personas/logout',
          {},
          { headers: { Authorization: `Bearer ${authToken}` } }
        );
      }
    } catch (err) {
      console.error('Error logging out:', err);
    } finally {
      // Clear token and persona
      localStorage.removeItem('praxion_auth_token');
      setAuthToken(null);
      setCurrentPersona(null);
      setCurrentSessionId(null);
      setMessages([]);
    }
  };

  // Create a new persona
  const createPersona = async (name, password) => {
    try {
      const res = await axios.post('http://localhost:8000/personas', { name, password });
      
      // Refresh personas list
      fetchPersonas();
      
      // Close persona modal
      setShowPersonaModal(false);
      
      // Show login modal to log in to the new persona
      setShowLoginModal(true);
    } catch (err) {
      console.error('Error creating persona:', err);
      alert('Failed to create persona. Please try again.');
    }
  };

  // Update persona settings
  const updatePersonaSettings = async (settings) => {
    if (!currentPersona || !authToken) return;
    
    try {
      const res = await axios.put(
        `http://localhost:8000/personas/${currentPersona.id}`,
        { settings },
        { headers: { Authorization: `Bearer ${authToken}` } }
      );
      
      // Update current persona
      setCurrentPersona(res.data);
      
      // Close settings modal
      setShowSettingsModal(false);
    } catch (err) {
      console.error('Error updating persona settings:', err);
      alert('Failed to update settings. Please try again.');
    }
  };

  // Handle text message submission
  const handleSubmit = async () => {
    if (!input.trim()) return;

    // Add user message to chat
    const userMessage = input;
    setMessages(prev => [...prev, { text: userMessage, isUser: true }]);
    setInput('');
    setIsLoading(true);

    try {
      // Send message to backend
      const res = await axios.post(
        'http://localhost:8000/chat', 
        null, 
        {
          params: { 
            message: userMessage,
            session_id: currentSessionId
          }
        }
      );
      
      // Add assistant response to chat
      const responseText = res.data.response;
      setMessages(prev => [...prev, { text: responseText, isUser: false }]);
      
      // Update current session ID if needed
      if (res.data.session_id !== currentSessionId) {
        setCurrentSessionId(res.data.session_id);
      }
      
      // Play audio response if voice is enabled
      if (currentPersona?.settings?.voice?.enabled) {
        playAudioResponse(responseText);
      }
    } catch (err) {
      console.error('Error sending message:', err);
      setMessages(prev => [...prev, { 
        text: 'Sorry, I encountered an error processing your request.', 
        isUser: false 
      }]);
    } finally {
      setIsLoading(false);
    }
  };

  // Handle voice input
  const handleVoiceInput = async (audioBlob, transcription) => {
    // If transcription is provided, use it directly
    if (transcription) {
      setInput(transcription);
      setTimeout(() => handleSubmit(), 500);
      return;
    }
    
    // Otherwise, send audio to backend for transcription
    try {
      const formData = new FormData();
      formData.append('audio', audioBlob);
      
      const res = await axios.post(
        'http://localhost:8000/chat/voice',
        formData,
        {
          params: { session_id: currentSessionId },
          headers: { 'Content-Type': 'multipart/form-data' }
        }
      );
      
      // Add user message and assistant response to chat
      const responseText = res.data.response;
      
      // Update current session ID if needed
      if (res.data.session_id !== currentSessionId) {
        setCurrentSessionId(res.data.session_id);
      }
      
      // Play audio response if voice is enabled
      if (currentPersona?.settings?.voice?.enabled) {
        playAudioResponse(responseText);
      }
    } catch (err) {
      console.error('Error processing voice input:', err);
      setMessages(prev => [...prev, { 
        text: 'Sorry, I encountered an error processing your voice input.', 
        isUser: false 
      }]);
    }
  };

  // Play audio response
  const playAudioResponse = async (text) => {
    try {
      setIsPlayingAudio(true);
      
      // Get audio URL
      const audioUrl = `http://localhost:8000/chat/voice/response?text=${encodeURIComponent(text)}`;
      
      // Play audio
      audioRef.current.src = audioUrl;
      await audioRef.current.play();
    } catch (err) {
      console.error('Error playing audio response:', err);
      setIsPlayingAudio(false);
    }
  };

  // Toggle sidebar
  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
    
    // Fetch personas and sessions when opening sidebar
    if (!sidebarOpen) {
      fetchPersonas();
      if (currentPersona) {
        fetchSessions(currentPersona.id);
      }
    }
  };

  return (
    <div className={`App ${sidebarOpen ? 'sidebar-open' : ''}`}>
      <Sidebar 
        isOpen={sidebarOpen}
        onClose={() => setSidebarOpen(false)}
        currentPersona={currentPersona}
        onNewChat={createNewSession}
        onLogin={() => setShowLoginModal(true)}
        onLogout={handleLogout}
        onCreatePersona={() => setShowPersonaModal(true)}
        onOpenSettings={() => setShowSettingsModal(true)}
      >
        <SessionList 
          sessions={sessions}
          currentSessionId={currentSessionId}
          onSelectSession={loadSession}
          onDeleteSession={deleteSession}
        />
      </Sidebar>
      
      <div className="main-content">
        <Header 
          welcomeMessage={welcomeMessage}
          sessionTitle={sessionTitle}
          onUpdateTitle={updateSessionTitle}
          onToggleSidebar={toggleSidebar}
          currentPersona={currentPersona}
        />
        
        <main className="chat-container">
          <div className="messages-container">
            {messages.length === 0 ? (
              <div className="empty-state">
                <p>Start a conversation with Praxion</p>
              </div>
            ) : (
              messages.map((msg, index) => (
                <ChatMessage 
                  key={index} 
                  message={msg.text} 
                  isUser={msg.isUser} 
                />
              ))
            )}
            <div ref={messagesEndRef} />
          </div>
          
          <div className="input-section">
            <VoiceControl 
              onTranscription={handleVoiceInput}
              isDisabled={isLoading || isPlayingAudio}
            />
            <ChatInput 
              value={input}
              onChange={setInput}
              onSubmit={handleSubmit}
              isLoading={isLoading}
              isDisabled={isPlayingAudio}
            />
          </div>
        </main>
      </div>
      
      {/* Modals */}
      {showPersonaModal && (
        <PersonaModal 
          onClose={() => setShowPersonaModal(false)}
          onCreatePersona={createPersona}
        />
      )}
      
      {showLoginModal && (
        <LoginModal 
          onClose={() => setShowLoginModal(false)}
          onLogin={handleLogin}
          personas={personas}
        />
      )}
      
      {showSettingsModal && currentPersona && (
        <SettingsModal 
          onClose={() => setShowSettingsModal(false)}
          onSave={updatePersonaSettings}
          settings={currentPersona.settings}
        />
      )}
    </div>
  );
}

export default App;
