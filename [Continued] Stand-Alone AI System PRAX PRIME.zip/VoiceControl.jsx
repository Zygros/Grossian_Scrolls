import React, { useState } from 'react';
import './VoiceControl.css';

const VoiceControl = ({ onTranscription }) => {
  const [isRecording, setIsRecording] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);

  const startRecording = async () => {
    setIsRecording(true);
    // In a real implementation, this would use the browser's microphone API
    // For this stub, we'll simulate recording and return a fixed response
    
    setTimeout(() => {
      stopRecording();
    }, 2000); // Simulate 2 seconds of recording
  };

  const stopRecording = async () => {
    setIsRecording(false);
    setIsProcessing(true);
    
    // Simulate processing the audio
    setTimeout(() => {
      // Simulate a transcription result
      const transcription = "Hello Praxion, how are you today?";
      onTranscription(transcription);
      setIsProcessing(false);
    }, 1000);
  };

  return (
    <div className="voice-control-container">
      <button
        className={`voice-button ${isRecording ? 'recording' : ''} ${isProcessing ? 'processing' : ''}`}
        onClick={isRecording ? stopRecording : startRecording}
        disabled={isProcessing}
      >
        <div className="button-content">
          <span className="button-icon">🎤</span>
          <span className="button-text">
            {isRecording ? 'Stop' : isProcessing ? 'Processing...' : 'Voice Input'}
          </span>
        </div>
      </button>
    </div>
  );
};

export default VoiceControl;
