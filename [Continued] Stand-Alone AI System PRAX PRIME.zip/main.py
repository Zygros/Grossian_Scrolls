#!/usr/bin/env python3
"""
Praxion - Main Backend API
FastAPI server for Praxion AI companion
"""

import logging
import os
import json
import tempfile
from typing import Dict, Any, List, Optional
from fastapi import FastAPI, HTTPException, Query, UploadFile, File, Form, Depends, Header
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, FileResponse, StreamingResponse
from pydantic import BaseModel
import uvicorn
import io

# Import Praxion modules
from .llm import LLMEngine
from .voice import VoiceSystem
from .persona_lock import PersonaLockSystem
from .infinite_scroll import InfiniteScrollEngine

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger("praxion.api")

# Initialize FastAPI app
app = FastAPI(
    title="Praxion API",
    description="Backend API for Praxion AI Companion",
    version="0.1.0"
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Allow all origins
    allow_credentials=True,
    allow_methods=["*"],  # Allow all methods
    allow_headers=["*"],  # Allow all headers
)

# Initialize Praxion modules
llm_engine = LLMEngine()
voice_system = VoiceSystem()
persona_lock = PersonaLockSystem()
infinite_scroll = InfiniteScrollEngine()

# Current active session
active_session_id = None

# Pydantic models for request/response
class ChatRequest(BaseModel):
    message: str
    session_id: Optional[str] = None

class ChatResponse(BaseModel):
    response: str
    session_id: str

class PersonaRequest(BaseModel):
    name: str
    password: Optional[str] = None

class PersonaUpdateRequest(BaseModel):
    name: Optional[str] = None
    settings: Optional[Dict[str, Any]] = None
    metadata: Optional[Dict[str, Any]] = None

class PasswordChangeRequest(BaseModel):
    current_password: str
    new_password: str

class SessionRequest(BaseModel):
    title: Optional[str] = None

class MessageRequest(BaseModel):
    content: str
    role: str = "user"

# Authentication dependency
async def get_auth_token(authorization: Optional[str] = Header(None)) -> Optional[str]:
    if authorization and authorization.startswith("Bearer "):
        token = authorization.replace("Bearer ", "")
        return token
    return None

async def validate_auth_token(token: Optional[str] = Depends(get_auth_token)) -> str:
    if not token or not persona_lock.validate_token(token):
        raise HTTPException(status_code=401, detail="Invalid or expired token")
    
    # Get persona ID from token
    for t, persona_id in persona_lock.auth_tokens.items():
        if t == token:
            return persona_id
    
    raise HTTPException(status_code=401, detail="Invalid token")

# Routes
@app.get("/")
async def root():
    """Root endpoint - returns welcome message"""
    return {"message": "Hello, Praxion! Your AI companion is ready."}

@app.get("/status")
async def status():
    """Get system status"""
    return {
        "status": "operational",
        "llm": llm_engine.status(),
        "voice": voice_system.status(),
        "persona": persona_lock.status(),
        "infinite_scroll": infinite_scroll.status()
    }

# Chat endpoints
@app.post("/chat", response_model=ChatResponse)
async def chat(message: str = Query(...), session_id: Optional[str] = Query(None)):
    """Send a message to Praxion and get a response"""
    global active_session_id
    
    # Get or create session
    if not session_id and not active_session_id:
        # Create a new session with default persona
        session_id = infinite_scroll.create_session("default")
        active_session_id = session_id
    elif not session_id:
        session_id = active_session_id
    
    # Add user message to session
    user_message = {
        "role": "user",
        "content": message
    }
    infinite_scroll.add_message(session_id, user_message)
    
    # Get conversation context
    context = infinite_scroll.get_context(session_id)
    
    # Generate response
    response = llm_engine.generate(message)
    
    # Add assistant response to session
    assistant_message = {
        "role": "assistant",
        "content": response
    }
    infinite_scroll.add_message(session_id, assistant_message)
    
    return {"response": response, "session_id": session_id}

@app.post("/chat/voice", response_model=ChatResponse)
async def chat_voice(audio: UploadFile = File(...), session_id: Optional[str] = Query(None)):
    """Send voice input to Praxion and get a text response"""
    global active_session_id
    
    # Read audio data
    audio_data = await audio.read()
    
    # Convert speech to text
    message = voice_system.speech_to_text(audio_data)
    
    # Get or create session
    if not session_id and not active_session_id:
        # Create a new session with default persona
        session_id = infinite_scroll.create_session("default")
        active_session_id = session_id
    elif not session_id:
        session_id = active_session_id
    
    # Add user message to session
    user_message = {
        "role": "user",
        "content": message,
        "metadata": {
            "input_type": "voice"
        }
    }
    infinite_scroll.add_message(session_id, user_message)
    
    # Get conversation context
    context = infinite_scroll.get_context(session_id)
    
    # Generate response
    response = llm_engine.generate(message)
    
    # Add assistant response to session
    assistant_message = {
        "role": "assistant",
        "content": response
    }
    infinite_scroll.add_message(session_id, assistant_message)
    
    return {"response": response, "session_id": session_id}

@app.get("/chat/voice/response")
async def get_voice_response(text: str = Query(...)):
    """Convert text to speech and return audio"""
    # Convert text to speech
    audio_data = voice_system.text_to_speech(text)
    
    # Return audio as streaming response
    return StreamingResponse(
        io.BytesIO(audio_data),
        media_type="audio/wav"
    )

# Persona endpoints
@app.get("/personas")
async def list_personas():
    """List all personas"""
    return persona_lock.list_personas()

@app.post("/personas")
async def create_persona(persona: PersonaRequest):
    """Create a new persona"""
    new_persona = persona_lock.create_persona(persona.name, persona.password)
    return new_persona

@app.post("/personas/login")
async def login(persona_id: str = Query(...), password: Optional[str] = Query(None)):
    """Log in to a persona"""
    token = persona_lock.authenticate(persona_id, password)
    if not token:
        raise HTTPException(status_code=401, detail="Authentication failed")
    
    return {"token": token, "persona_id": persona_id}

@app.post("/personas/logout")
async def logout(persona_id: str = Depends(validate_auth_token), token: str = Depends(get_auth_token)):
    """Log out of a persona"""
    success = persona_lock.logout(token)
    if not success:
        raise HTTPException(status_code=400, detail="Logout failed")
    
    return {"success": True}

@app.get("/personas/current")
async def get_current_persona(persona_id: str = Depends(validate_auth_token)):
    """Get the current persona"""
    persona = persona_lock.get_persona(persona_id)
    if not persona:
        raise HTTPException(status_code=404, detail="Persona not found")
    
    return persona

@app.put("/personas/{persona_id}")
async def update_persona(
    persona_id: str,
    updates: PersonaUpdateRequest,
    token: str = Depends(get_auth_token)
):
    """Update a persona"""
    updated_persona = persona_lock.update_persona(persona_id, updates.dict(exclude_unset=True), token)
    if not updated_persona:
        raise HTTPException(status_code=400, detail="Update failed")
    
    return updated_persona

@app.post("/personas/{persona_id}/password")
async def change_password(
    persona_id: str,
    password_change: PasswordChangeRequest,
    token: str = Depends(get_auth_token)
):
    """Change a persona's password"""
    success = persona_lock.change_password(
        persona_id,
        password_change.current_password,
        password_change.new_password,
        token
    )
    if not success:
        raise HTTPException(status_code=400, detail="Password change failed")
    
    return {"success": True}

@app.delete("/personas/{persona_id}")
async def delete_persona(
    persona_id: str,
    password: Optional[str] = Query(None),
    token: str = Depends(get_auth_token)
):
    """Delete a persona"""
    success = persona_lock.delete_persona(persona_id, password, token)
    if not success:
        raise HTTPException(status_code=400, detail="Delete failed")
    
    return {"success": True}

# Session endpoints
@app.get("/sessions")
async def list_sessions(persona_id: Optional[str] = Query(None)):
    """List all sessions"""
    return infinite_scroll.list_sessions(persona_id)

@app.post("/sessions")
async def create_session(
    session: SessionRequest,
    persona_id: str = Depends(validate_auth_token)
):
    """Create a new session"""
    session_id = infinite_scroll.create_session(persona_id, session.title)
    return {"session_id": session_id}

@app.get("/sessions/{session_id}")
async def get_session(session_id: str):
    """Get a session"""
    session = infinite_scroll.load_session(session_id)
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    
    return session

@app.get("/sessions/{session_id}/messages")
async def get_messages(
    session_id: str,
    limit: Optional[int] = Query(None),
    offset: int = Query(0)
):
    """Get messages from a session"""
    messages = infinite_scroll.get_messages(session_id, limit, offset)
    return {"messages": messages}

@app.post("/sessions/{session_id}/messages")
async def add_message(
    session_id: str,
    message: MessageRequest,
    persona_id: str = Depends(validate_auth_token)
):
    """Add a message to a session"""
    success = infinite_scroll.add_message(session_id, message.dict())
    if not success:
        raise HTTPException(status_code=400, detail="Failed to add message")
    
    return {"success": True}

@app.put("/sessions/{session_id}/title")
async def update_session_title(
    session_id: str,
    title: str = Query(...),
    persona_id: str = Depends(validate_auth_token)
):
    """Update a session's title"""
    success = infinite_scroll.update_session_title(session_id, title)
    if not success:
        raise HTTPException(status_code=400, detail="Failed to update title")
    
    return {"success": True}

@app.delete("/sessions/{session_id}")
async def delete_session(
    session_id: str,
    persona_id: str = Depends(validate_auth_token)
):
    """Delete a session"""
    success = infinite_scroll.delete_session(session_id)
    if not success:
        raise HTTPException(status_code=400, detail="Failed to delete session")
    
    return {"success": True}

@app.get("/sessions/{session_id}/export")
async def export_session(
    session_id: str,
    format: str = Query("json")
):
    """Export a session"""
    export_data = infinite_scroll.export_session(session_id, format)
    if not export_data:
        raise HTTPException(status_code=404, detail="Session not found")
    
    if format == "json":
        return export_data
    elif format == "text":
        # Create a temporary file
        with tempfile.NamedTemporaryFile(suffix=".txt", delete=False) as temp_file:
            temp_file.write(export_data.encode('utf-8'))
            temp_path = temp_file.name
        
        # Return the file
        return FileResponse(
            temp_path,
            media_type="text/plain",
            filename=f"session_{session_id}.txt"
        )
    else:
        raise HTTPException(status_code=400, detail="Unsupported format")

# Voice endpoints
@app.post("/voice/transcribe")
async def transcribe(audio: UploadFile = File(...)):
    """Transcribe speech to text"""
    audio_data = await audio.read()
    text = voice_system.speech_to_text(audio_data)
    return {"text": text}

@app.post("/voice/synthesize")
async def synthesize(text: str = Query(...)):
    """Synthesize text to speech"""
    audio_data = voice_system.text_to_speech(text)
    
    return StreamingResponse(
        io.BytesIO(audio_data),
        media_type="audio/wav"
    )

# Run the server
if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
