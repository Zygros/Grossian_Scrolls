#!/bin/bash
# Create necessary directories for offline resources
mkdir -p resources/models/llm
mkdir -p resources/models/voice
mkdir -p resources/memory

# Download minimal models for offline operation
echo "Downloading minimal models for offline operation..."

# For a real implementation, this would download actual models
# For this stub, we'll create placeholder files

# Create placeholder for LLM model
echo "Creating LLM model placeholder..."
cat > resources/models/llm/model_info.json << EOL
{
  "name": "praxion-mini-llm",
  "version": "0.1.0",
  "description": "Minimal LLM for Praxion offline operation",
  "size": "500MB",
  "type": "transformer",
  "quantization": "int8"
}
EOL

# Create placeholder for voice recognition model
echo "Creating voice recognition model placeholder..."
cat > resources/models/voice/whisper_tiny.json << EOL
{
  "name": "whisper-tiny",
  "version": "0.1.0",
  "description": "Minimal speech recognition model for Praxion",
  "size": "75MB",
  "language": "en",
  "sample_rate": 16000
}
EOL

# Create placeholder for TTS model
echo "Creating TTS model placeholder..."
cat > resources/models/voice/tts_mini.json << EOL
{
  "name": "tts-mini",
  "version": "0.1.0",
  "description": "Minimal text-to-speech model for Praxion",
  "size": "50MB",
  "voice": "neutral",
  "sample_rate": 22050
}
EOL

# Create initial memory file
echo "Creating initial memory file..."
cat > resources/memory/conversation_history.json << EOL
[]
EOL

echo "Resource setup complete!"
