#!/bin/bash
# Praxion - Main startup script

# Set up virtual environment if it doesn't exist
if [ ! -d ".venv" ]; then
    echo "Setting up virtual environment..."
    python3 -m venv .venv
fi

# Activate virtual environment
source .venv/bin/activate

# Install dependencies if needed
if [ ! -f ".venv/.installed" ]; then
    echo "Installing dependencies..."
    pip install -r requirements.txt
    touch .venv/.installed
fi

# Function to start the backend
start_backend() {
    echo "Starting Praxion backend..."
    uvicorn src.backend.main:app --reload
}

# Function to start the desktop UI
start_desktop() {
    echo "Starting desktop UI..."
    cd src/ui/desktop
    npm install
    npm run dev
}

# Function to start the mobile UI
start_mobile() {
    echo "Starting mobile UI..."
    cd src/ui/mobile
    yarn install
    expo start
}

# Function to run tests
run_tests() {
    echo "Running tests..."
    pytest tests/
}

# Main execution
case "$1" in
    backend)
        start_backend
        ;;
    desktop)
        start_desktop
        ;;
    mobile)
        start_mobile
        ;;
    test)
        run_tests
        ;;
    *)
        echo "Praxion - Standalone AI Companion"
        echo "Usage: $0 {backend|desktop|mobile|test}"
        echo ""
        echo "Commands:"
        echo "  backend  - Start the backend API server"
        echo "  desktop  - Start the desktop UI"
        echo "  mobile   - Start the mobile UI"
        echo "  test     - Run tests"
        ;;
esac
