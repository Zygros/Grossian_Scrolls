#!/usr/bin/env python3
"""
Praxion - Main Package Initialization
"""

__version__ = "0.1.0"
