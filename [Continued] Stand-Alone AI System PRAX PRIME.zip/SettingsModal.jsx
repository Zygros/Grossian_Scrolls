import React, { useState } from 'react';
import './SettingsModal.css';

const SettingsModal = ({ onClose, onSave, settings }) => {
  const [voiceEnabled, setVoiceEnabled] = useState(settings?.voice?.enabled || false);
  const [voiceVolume, setVoiceVolume] = useState(settings?.voice?.volume || 0.8);
  const [voiceRate, setVoiceRate] = useState(settings?.voice?.rate || 1.0);
  const [theme, setTheme] = useState(settings?.theme || 'light');
  const [privacyLevel, setPrivacyLevel] = useState(settings?.privacy_level || 'standard');

  const handleSubmit = (e) => {
    e.preventDefault();
    
    // Prepare updated settings
    const updatedSettings = {
      voice: {
        enabled: voiceEnabled,
        volume: parseFloat(voiceVolume),
        rate: parseFloat(voiceRate)
      },
      theme,
      privacy_level: privacyLevel
    };
    
    // Save settings
    onSave(updatedSettings);
  };

  return (
    <div className="modal-overlay">
      <div className="modal-container settings-modal">
        <div className="modal-header">
          <h2>Settings</h2>
          <button className="close-button" onClick={onClose}>×</button>
        </div>
        
        <form onSubmit={handleSubmit}>
          <div className="settings-section">
            <h3>Voice Settings</h3>
            
            <div className="form-group checkbox">
              <input
                id="voice-enabled"
                type="checkbox"
                checked={voiceEnabled}
                onChange={(e) => setVoiceEnabled(e.target.checked)}
              />
              <label htmlFor="voice-enabled">Enable voice responses</label>
            </div>
            
            <div className="form-group">
              <label htmlFor="voice-volume">Volume: {voiceVolume}</label>
              <input
                id="voice-volume"
                type="range"
                min="0"
                max="1"
                step="0.1"
                value={voiceVolume}
                onChange={(e) => setVoiceVolume(e.target.value)}
                disabled={!voiceEnabled}
              />
            </div>
            
            <div className="form-group">
              <label htmlFor="voice-rate">Speech Rate: {voiceRate}x</label>
              <input
                id="voice-rate"
                type="range"
                min="0.5"
                max="2"
                step="0.1"
                value={voiceRate}
                onChange={(e) => setVoiceRate(e.target.value)}
                disabled={!voiceEnabled}
              />
            </div>
          </div>
          
          <div className="settings-section">
            <h3>Appearance</h3>
            
            <div className="form-group">
              <label htmlFor="theme">Theme</label>
              <select
                id="theme"
                value={theme}
                onChange={(e) => setTheme(e.target.value)}
              >
                <option value="light">Light</option>
                <option value="dark">Dark</option>
                <option value="system">System Default</option>
              </select>
            </div>
          </div>
          
          <div className="settings-section">
            <h3>Privacy</h3>
            
            <div className="form-group">
              <label htmlFor="privacy-level">Privacy Level</label>
              <select
                id="privacy-level"
                value={privacyLevel}
                onChange={(e) => setPrivacyLevel(e.target.value)}
              >
                <option value="standard">Standard</option>
                <option value="high">High Privacy</option>
                <option value="maximum">Maximum Privacy</option>
              </select>
            </div>
          </div>
          
          <div className="form-actions">
            <button type="button" className="cancel-button" onClick={onClose}>Cancel</button>
            <button type="submit" className="save-button">Save Settings</button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default SettingsModal;
