#!/usr/bin/env python3
"""
Praxion - Memory System
Manages persistent storage, context, and recall capabilities
"""

import logging
import json
import os
import time
from typing import Dict, Any, List, Optional
from datetime import datetime

logger = logging.getLogger("praxion.memory")

class MemorySystem:
    """
    The MemorySystem manages persistent storage, context, and recall
    capabilities for Praxion.
    """
    
    def __init__(self, memory_path: str = None):
        """
        Initialize the MemorySystem
        
        Args:
            memory_path: Path to the memory storage directory
        """
        self.memory_path = memory_path or os.path.join(os.path.dirname(__file__), "../../resources/memory")
        os.makedirs(self.memory_path, exist_ok=True)
        
        self.conversation_history = []
        self.max_history_length = 100
        self._load_conversation_history()
        
        logger.info("MemorySystem initialized")
    
    def _load_conversation_history(self):
        """Load conversation history from storage"""
        history_file = os.path.join(self.memory_path, "conversation_history.json")
        
        if os.path.exists(history_file):
            try:
                with open(history_file, 'r') as f:
                    self.conversation_history = json.load(f)
                logger.info(f"Loaded {len(self.conversation_history)} conversation entries")
            except Exception as e:
                logger.error(f"Error loading conversation history: {str(e)}")
                self.conversation_history = []
    
    def _save_conversation_history(self):
        """Save conversation history to storage"""
        history_file = os.path.join(self.memory_path, "conversation_history.json")
        
        try:
            with open(history_file, 'w') as f:
                json.dump(self.conversation_history, f)
            logger.info(f"Saved {len(self.conversation_history)} conversation entries")
        except Exception as e:
            logger.error(f"Error saving conversation history: {str(e)}")
    
    def store_interaction(self, user_message: str, assistant_response: str):
        """
        Store a user-assistant interaction in memory
        
        Args:
            user_message: The user's message
            assistant_response: The assistant's response
        """
        timestamp = datetime.now().isoformat()
        
        interaction = {
            "timestamp": timestamp,
            "user_message": user_message,
            "assistant_response": assistant_response
        }
        
        self.conversation_history.append(interaction)
        
        # Trim history if it exceeds the maximum length
        if len(self.conversation_history) > self.max_history_length:
            self.conversation_history = self.conversation_history[-self.max_history_length:]
        
        # Save to disk
        self._save_conversation_history()
    
    def get_relevant_context(self, query: str, max_items: int = 5) -> List[Dict[str, Any]]:
        """
        Retrieve relevant context based on the current query
        
        Args:
            query: The current user query
            max_items: Maximum number of context items to return
            
        Returns:
            List of relevant context items
        """
        # In a real implementation, this would use semantic search or other relevance methods
        # For this stub, we'll just return the most recent conversations
        
        context = []
        for interaction in reversed(self.conversation_history[-max_items:]):
            context.append({
                "timestamp": interaction["timestamp"],
                "content": f"User: {interaction['user_message']}\nAssistant: {interaction['assistant_response']}"
            })
        
        return list(reversed(context))
    
    def clear_history(self):
        """Clear the conversation history"""
        self.conversation_history = []
        self._save_conversation_history()
        logger.info("Conversation history cleared")
    
    def status(self) -> Dict[str, Any]:
        """
        Get the current status of the MemorySystem
        
        Returns:
            Dict containing status information
        """
        return {
            "status": "operational",
            "history_entries": len(self.conversation_history),
            "memory_path": self.memory_path
        }
