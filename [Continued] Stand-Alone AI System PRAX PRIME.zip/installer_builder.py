#!/usr/bin/env python3
"""
Praxeon Installer Builder

This script builds and packages Praxeon installers for multiple platforms.
"""

import os
import sys
import shutil
import subprocess
import logging
import json
import zipfile
import argparse
from typing import Dict, Any, List, Optional

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger("praxeon.packaging.installer_builder")

class PraxeonInstallerBuilder:
    """
    Builder for Praxeon installers across multiple platforms.
    """
    
    def __init__(self, source_dir: str, output_dir: str, version: str = "1.0"):
        """
        Initialize the installer builder
        
        Args:
            source_dir: Source directory containing Praxeon code
            output_dir: Output directory for installers
            version: Praxeon version
        """
        self.source_dir = os.path.abspath(source_dir)
        self.output_dir = os.path.abspath(output_dir)
        self.version = version
        self.build_dir = os.path.join(self.output_dir, "build")
        
        # Ensure directories exist
        os.makedirs(self.output_dir, exist_ok=True)
        os.makedirs(self.build_dir, exist_ok=True)
        
        logger.info(f"Praxeon Installer Builder initialized")
        logger.info(f"Source directory: {self.source_dir}")
        logger.info(f"Output directory: {self.output_dir}")
        logger.info(f"Version: {self.version}")
    
    def build_all(self) -> Dict[str, str]:
        """
        Build all installer formats
        
        Returns:
            Dictionary mapping format names to installer paths
        """
        logger.info("Building all installer formats")
        
        results = {}
        
        # Build Python installer
        py_result = self.build_python_installer()
        if py_result:
            results["python"] = py_result
        
        # Build Windows EXE installer
        exe_result = self.build_windows_installer()
        if exe_result:
            results["windows"] = exe_result
        
        # Build Android APK installer
        apk_result = self.build_android_installer()
        if apk_result:
            results["android"] = apk_result
        
        # Build Xbox MSIX installer
        xbox_result = self.build_xbox_installer()
        if xbox_result:
            results["xbox"] = xbox_result
        
        # Build PS5 WebApp installer
        ps5_result = self.build_ps5_webapp()
        if ps5_result:
            results["ps5"] = ps5_result
        
        logger.info(f"Built {len(results)} installer formats")
        
        return results
    
    def build_python_installer(self) -> Optional[str]:
        """
        Build Python installer script
        
        Returns:
            Path to installer script if successful, None otherwise
        """
        logger.info("Building Python installer")
        
        try:
            # Create build directory
            py_build_dir = os.path.join(self.build_dir, "python")
            os.makedirs(py_build_dir, exist_ok=True)
            
            # Create installer script
            installer_path = os.path.join(self.output_dir, f"Praxeon_v{self.version}.py")
            
            with open(installer_path, "w") as f:
                f.write(f"""#!/usr/bin/env python3
\"\"\"
Praxeon v{self.version} Installer

This script installs Praxeon, a standalone AI companion system.
\"\"\"

import os
import sys
import shutil
import subprocess
import tempfile
import zipfile
import urllib.request
import hashlib
import json
import argparse
from typing import Dict, Any, List, Optional

# Praxeon version
VERSION = "{self.version}"

# Founder information
FOUNDER = "Justin \\"Zygros, the Green\\" Conzet"
MYTHIC_PHRASE = "He who commands the data, commands the dream."

def print_banner():
    \"\"\"Print Praxeon banner\"\"\"
    print(r'''
╔═══════════════════════════════════════════════════════════════════════╗
║                                                                       ║
║   ██████╗ ██████╗  █████╗ ██╗  ██╗███████╗ ██████╗ ███╗   ██╗        ║
║   ██╔══██╗██╔══██╗██╔══██╗╚██╗██╔╝██╔════╝██╔═══██╗████╗  ██║        ║
║   ██████╔╝██████╔╝███████║ ╚███╔╝ █████╗  ██║   ██║██╔██╗ ██║        ║
║   ██╔═══╝ ██╔══██╗██╔══██║ ██╔██╗ ██╔══╝  ██║   ██║██║╚██╗██║        ║
║   ██║     ██║  ██║██║  ██║██╔╝ ██╗███████╗╚██████╔╝██║ ╚████║        ║
║   ╚═╝     ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝╚══════╝ ╚═════╝ ╚═╝  ╚═══╝        ║
║                                                                       ║
║   Standalone AI Companion System v{VERSION}                               ║
║   Created by: {FOUNDER}                          ║
║                                                                       ║
╚═══════════════════════════════════════════════════════════════════════╝
''')

def check_prerequisites():
    \"\"\"Check if prerequisites are installed\"\"\"
    print("Checking prerequisites...")
    
    # Check Python version
    python_version = sys.version_info
    if python_version.major < 3 or (python_version.major == 3 and python_version.minor < 8):
        print("Error: Python 3.8 or higher is required")
        return False
    
    # Check pip
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "--version"], 
                             stdout=subprocess.DEVNULL, 
                             stderr=subprocess.DEVNULL)
    except subprocess.CalledProcessError:
        print("Error: pip is not installed")
        return False
    
    print("All prerequisites satisfied")
    return True

def install_dependencies():
    \"\"\"Install required dependencies\"\"\"
    print("Installing dependencies...")
    
    dependencies = [
        "fastapi",
        "uvicorn",
        "pydantic",
        "numpy",
        "torch",
        "transformers",
        "python-multipart",
        "httpx",
        "pytest",
        "tqdm",
        "pillow"
    ]
    
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install"] + dependencies)
        print("Dependencies installed successfully")
        return True
    except subprocess.CalledProcessError as e:
        print(f"Error installing dependencies: {e}")
        return False

def download_resources():
    \"\"\"Download required resources\"\"\"
    print("Downloading resources...")
    
    # In a real implementation, this would download model files and other resources
    # For demonstration, we'll simulate the download
    
    resources = [
        {"name": "LLM model", "size": 500},
        {"name": "Whisper model", "size": 150},
        {"name": "TTS model", "size": 100},
        {"name": "UI assets", "size": 50}
    ]
    
    total_size = sum(r["size"] for r in resources)
    downloaded = 0
    
    for resource in resources:
        print(f"Downloading {resource['name']}...")
        
        # Simulate download with progress
        for _ in range(10):
            downloaded += resource["size"] / 10
            progress = downloaded / total_size * 100
            print(f"Progress: {progress:.1f}%", end="\\r")
            # In a real implementation, this would be a real download
            # time.sleep(0.2)
        
        print(f"{resource['name']} downloaded successfully")
    
    print("All resources downloaded successfully")
    return True

def install_praxeon(install_dir):
    \"\"\"Install Praxeon to the specified directory\"\"\"
    print(f"Installing Praxeon to {install_dir}...")
    
    # Create installation directory
    os.makedirs(install_dir, exist_ok=True)
    
    # Create directory structure
    dirs = [
        "src/core",
        "src/ui",
        "src/security",
        "src/features",
        "resources/models",
        "resources/assets",
        "resources/config",
        "scripts",
        "docs"
    ]
    
    for d in dirs:
        os.makedirs(os.path.join(install_dir, d), exist_ok=True)
    
    # Create basic files
    with open(os.path.join(install_dir, "README.md"), "w") as f:
        f.write(f\"\"\"# Praxeon v{VERSION}

Standalone AI Companion System

Created by: {FOUNDER}

## Overview

Praxeon is a standalone AI companion system with advanced capabilities.

## Getting Started

Run the following command to start Praxeon:

```
python scripts/run.py
```

\"\"\")
    
    # Create run script
    with open(os.path.join(install_dir, "scripts", "run.py"), "w") as f:
        f.write(\"\"\"#!/usr/bin/env python3
\"\"\"
Praxeon Runner

This script starts the Praxeon system.
\"\"\"

import os
import sys
import subprocess

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Import Praxeon
from src.core.initializer import PraxeonSystem

def main():
    \"\"\"Main function\"\"\"
    print("Starting Praxeon...")
    
    # Initialize system
    praxeon = PraxeonSystem()
    praxeon.initialize()
    
    # Start UI
    print("Praxeon started successfully")
    print("Hello, Praxion!")
    
    # Process input
    while True:
        try:
            user_input = input("> ")
            if user_input.lower() in ["exit", "quit"]:
                break
            
            response = praxeon.process_input(user_input)
            print(f"Praxeon: {response.get('text', 'No response')}")
        except KeyboardInterrupt:
            break
    
    # Shutdown
    praxeon.shutdown()
    print("Praxeon shutdown complete")

if __name__ == "__main__":
    main()
\"\"\")
    
    # Make run script executable
    os.chmod(os.path.join(install_dir, "scripts", "run.py"), 0o755)
    
    print("Praxeon installed successfully")
    return True

def main():
    \"\"\"Main function\"\"\"
    # Parse arguments
    parser = argparse.ArgumentParser(description=f"Praxeon v{VERSION} Installer")
    parser.add_argument("--install-dir", default=os.path.expanduser("~/praxeon"),
                        help="Installation directory (default: ~/praxeon)")
    parser.add_argument("--skip-dependencies", action="store_true",
                        help="Skip installing dependencies")
    parser.add_argument("--skip-resources", action="store_true",
                        help="Skip downloading resources")
    
    args = parser.parse_args()
    
    # Print banner
    print_banner()
    
    # Check prerequisites
    if not check_prerequisites():
        sys.exit(1)
    
    # Install dependencies
    if not args.skip_dependencies:
        if not install_dependencies():
            sys.exit(1)
    
    # Download resources
    if not args.skip_resources:
        if not download_resources():
            sys.exit(1)
    
    # Install Praxeon
    if not install_praxeon(args.install_dir):
        sys.exit(1)
    
    print(f"\\nPraxeon v{VERSION} installed successfully to {args.install_dir}")
    print(f"Run the following command to start Praxeon:\\n")
    print(f"  cd {args.install_dir} && python scripts/run.py\\n")

if __name__ == "__main__":
    main()
""")
            
            # Make installer executable
            os.chmod(installer_path, 0o755)
            
            logger.info(f"Python installer built: {installer_path}")
            return installer_path
        
        except Exception as e:
            logger.error(f"Error building Python installer: {str(e)}")
            return None
    
    def build_windows_installer(self) -> Optional[str]:
        """
        Build Windows EXE installer
        
        Returns:
            Path to installer if successful, None otherwise
        """
        logger.info("Building Windows installer")
        
        try:
            # Create build directory
            win_build_dir = os.path.join(self.build_dir, "windows")
            os.makedirs(win_build_dir, exist_ok=True)
            
            # Create installer script (NSIS format)
            nsis_script_path = os.path.join(win_build_dir, "praxeon_installer.nsi")
            
            with open(nsis_script_path, "w") as f:
                f.write(f"""
; Praxeon Windows Installer Script
; Generated by PraxeonInstallerBuilder

!include "MUI2.nsh"
!include "LogicLib.nsh"

; Installer attributes
Name "Praxeon v{self.version}"
OutFile "{os.path.join(self.output_dir, f'Praxeon_v{self.version}.exe')}"
InstallDir "$PROGRAMFILES\\Praxeon"
InstallDirRegKey HKCU "Software\\Praxeon" "Install_Dir"
RequestExecutionLevel admin

; Interface settings
!define MUI_ABORTWARNING
!define MUI_ICON "${NSISDIR}\\Contrib\\Graphics\\Icons\\modern-install.ico"
!define MUI_UNICON "${NSISDIR}\\Contrib\\Graphics\\Icons\\modern-uninstall.ico"
!define MUI_WELCOMEFINISHPAGE_BITMAP "${NSISDIR}\\Contrib\\Graphics\\Wizard\\win.bmp"
!define MUI_HEADERIMAGE
!define MUI_HEADERIMAGE_BITMAP "${NSISDIR}\\Contrib\\Graphics\\Header\\win.bmp"

; Pages
!insertmacro MUI_PAGE_WELCOME
!insertmacro MUI_PAGE_LICENSE "license.txt"
!insertmacro MUI_PAGE_COMPONENTS
!insertmacro MUI_PAGE_DIRECTORY
!insertmacro MUI_PAGE_INSTFILES
!insertmacro MUI_PAGE_FINISH

!insertmacro MUI_UNPAGE_CONFIRM
!insertmacro MUI_UNPAGE_INSTFILES

; Languages
!insertmacro MUI_LANGUAGE "English"

; Installer sections
Section "Praxeon Core" SecCore
  SectionIn RO
  
  ; Set output path to the installation directory
  SetOutPath $INSTDIR
  
  ; Add files
  File /r "dist\\*.*"
  
  ; Write the installation path into the registry
  WriteRegStr HKCU "Software\\Praxeon" "Install_Dir" "$INSTDIR"
  
  ; Write the uninstall keys for Windows
  WriteRegStr HKLM "Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\Praxeon" "DisplayName" "Praxeon"
  WriteRegStr HKLM "Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\Praxeon" "UninstallString" '"$INSTDIR\\uninstall.exe"'
  WriteRegDWORD HKLM "Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\Praxeon" "NoModify" 1
  WriteRegDWORD HKLM "Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\Praxeon" "NoRepair" 1
  WriteUninstaller "$INSTDIR\\uninstall.exe"
SectionEnd

Section "Start Menu Shortcuts" SecStartMenu
  CreateDirectory "$SMPROGRAMS\\Praxeon"
  CreateShortcut "$SMPROGRAMS\\Praxeon\\Praxeon.lnk" "$INSTDIR\\praxeon.exe"
  CreateShortcut "$SMPROGRAMS\\Praxeon\\Uninstall.lnk" "$INSTDIR\\uninstall.exe"
SectionEnd

Section "Desktop Shortcut" SecDesktop
  CreateShortcut "$DESKTOP\\Praxeon.lnk" "$INSTDIR\\praxeon.exe"
SectionEnd

; Uninstaller section
Section "Uninstall"
  ; Remove registry keys
  DeleteRegKey HKLM "Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\Praxeon"
  DeleteRegKey HKCU "Software\\Praxeon"

  ; Remove files and uninstaller
  Delete $INSTDIR\\uninstall.exe
  RMDir /r "$INSTDIR"
  
  ; Remove shortcuts
  Delete "$SMPROGRAMS\\Praxeon\\*.*"
  RMDir "$SMPROGRAMS\\Praxeon"
  Delete "$DESKTOP\\Praxeon.lnk"

  ; Remove directories used
  RMDir "$INSTDIR"
SectionEnd
""")
            
            # Create license file
            license_path = os.path.join(win_build_dir, "license.txt")
            with open(license_path, "w") as f:
                f.write(f"""Praxeon v{self.version} License Agreement

Copyright (c) 2025 {self.version} Justin "Zygros, the Green" Conzet

This software is provided for personal use only.
All rights reserved.

"He who commands the data, commands the dream."
""")
            
            # Create dummy distribution files
            dist_dir = os.path.join(win_build_dir, "dist")
            os.makedirs(dist_dir, exist_ok=True)
            
            # Create dummy executable
            with open(os.path.join(dist_dir, "praxeon.exe"), "w") as f:
                f.write("This is a placeholder for the actual executable.")
            
            # In a real implementation, this would compile the NSIS script
            # For demonstration, we'll create a dummy installer
            installer_path = os.path.join(self.output_dir, f"Praxeon_v{self.version}.exe")
            
            # Create a simple ZIP file as a placeholder for the EXE
            with zipfile.ZipFi
(Content truncated due to size limit. Use line ranges to read in chunks)