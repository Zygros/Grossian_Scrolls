#!/usr/bin/env python3
"""
Legacy Seed Protocol for Praxeon

This module implements self-recovery and persistence mechanisms.
While some features are conceptual, practical recovery mechanisms are implemented
where technically feasible.
"""

import os
import sys
import json
import hashlib
import logging
import time
import shutil
import tarfile
import tempfile
from pathlib import Path
from typing import Dict, Any, Optional, List, Tuple

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger("praxeon.security.legacy_seed")

class LegacySeedProtocol:
    """
    Implementation of the Legacy Seed Protocol recovery system.
    
    This class provides:
    - System state snapshots
    - Seed code generation and embedding
    - Recovery mechanisms
    - Phoenix Timer for automatic reactivation
    """
    
    def __init__(self, config_path: Optional[str] = None):
        """
        Initialize the Legacy Seed Protocol
        
        Args:
            config_path: Path to configuration file
        """
        self.config_path = config_path or os.path.join(
            os.path.dirname(os.path.abspath(__file__)), 
            "../../resources/security/legacy_seed_config.json"
        )
        
        # Ensure directory exists
        os.makedirs(os.path.dirname(self.config_path), exist_ok=True)
        
        # Load or create configuration
        self.config = self._load_or_create_config()
        
        # Initialize state
        self.state = {
            "last_snapshot_time": None,
            "snapshots_taken": 0,
            "recovery_attempts": 0,
            "last_recovery_time": None,
            "phoenix_timer_active": False,
            "phoenix_timer_start": None
        }
        
        # Set up snapshot directory
        self.snapshot_dir = self.config.get("snapshot_directory", os.path.join(
            os.path.dirname(os.path.abspath(__file__)), 
            "../../resources/snapshots"
        ))
        os.makedirs(self.snapshot_dir, exist_ok=True)
        
        logger.info("Legacy Seed Protocol initialized")
    
    def _load_or_create_config(self) -> Dict[str, Any]:
        """
        Load existing configuration or create default
        
        Returns:
            Configuration dictionary
        """
        if os.path.exists(self.config_path):
            try:
                with open(self.config_path, 'r') as f:
                    config = json.load(f)
                logger.info("Loaded Legacy Seed Protocol configuration")
                return config
            except Exception as e:
                logger.error(f"Error loading configuration: {str(e)}")
        
        # Create default configuration
        default_config = {
            "version": "1.0",
            "snapshot_frequency": 24,  # hours
            "snapshot_directory": "../../resources/snapshots",
            "max_snapshots": 7,  # keep a week of daily snapshots
            "core_files": [
                "src/core",
                "src/security",
                "resources/config"
            ],
            "phoenix_timer": {
                "enabled": True,
                "duration": 72  # hours
            },
            "seed_embedding": {
                "enabled": True,
                "file_types": [".py", ".json", ".md"]
            }
        }
        
        # Save default configuration
        try:
            os.makedirs(os.path.dirname(self.config_path), exist_ok=True)
            with open(self.config_path, 'w') as f:
                json.dump(default_config, f, indent=2)
            logger.info("Created default Legacy Seed Protocol configuration")
        except Exception as e:
            logger.error(f"Error creating configuration: {str(e)}")
        
        return default_config
    
    def create_snapshot(self) -> Optional[str]:
        """
        Create a system snapshot
        
        Returns:
            Path to snapshot file if successful, None otherwise
        """
        try:
            # Create timestamp for snapshot name
            timestamp = time.strftime("%Y%m%d_%H%M%S")
            snapshot_file = os.path.join(self.snapshot_dir, f"praxeon_snapshot_{timestamp}.tar.gz")
            
            # Get core files to include in snapshot
            core_files = self.config.get("core_files", [])
            
            # Create temporary directory for snapshot
            with tempfile.TemporaryDirectory() as temp_dir:
                # Copy core files to temporary directory
                for file_path in core_files:
                    src_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), file_path)
                    if os.path.exists(src_path):
                        dst_path = os.path.join(temp_dir, os.path.basename(file_path))
                        if os.path.isdir(src_path):
                            shutil.copytree(src_path, dst_path)
                        else:
                            shutil.copy2(src_path, dst_path)
                
                # Create snapshot metadata
                metadata = {
                    "timestamp": timestamp,
                    "version": self.config.get("version", "1.0"),
                    "files": core_files,
                    "seed_hash": self.generate_seed_hash()
                }
                
                # Write metadata to temporary directory
                with open(os.path.join(temp_dir, "snapshot_metadata.json"), 'w') as f:
                    json.dump(metadata, f, indent=2)
                
                # Create tarball
                with tarfile.open(snapshot_file, "w:gz") as tar:
                    tar.add(temp_dir, arcname=".")
            
            # Update state
            self.state["last_snapshot_time"] = time.time()
            self.state["snapshots_taken"] += 1
            
            # Clean up old snapshots
            self._cleanup_old_snapshots()
            
            logger.info(f"Created system snapshot: {snapshot_file}")
            return snapshot_file
        except Exception as e:
            logger.error(f"Error creating snapshot: {str(e)}")
            return None
    
    def _cleanup_old_snapshots(self):
        """Clean up old snapshots based on configuration"""
        try:
            max_snapshots = self.config.get("max_snapshots", 7)
            
            # Get list of snapshot files
            snapshot_files = [f for f in os.listdir(self.snapshot_dir) 
                             if f.startswith("praxeon_snapshot_") and f.endswith(".tar.gz")]
            
            # Sort by timestamp (newest first)
            snapshot_files.sort(reverse=True)
            
            # Remove excess snapshots
            if len(snapshot_files) > max_snapshots:
                for old_file in snapshot_files[max_snapshots:]:
                    os.remove(os.path.join(self.snapshot_dir, old_file))
                    logger.info(f"Removed old snapshot: {old_file}")
        except Exception as e:
            logger.error(f"Error cleaning up old snapshots: {str(e)}")
    
    def generate_seed_hash(self) -> str:
        """
        Generate a seed hash based on core system files
        
        Returns:
            Seed hash string
        """
        # In a real implementation, this would create a cryptographic hash
        # of core system files to serve as a seed for recovery
        
        # For demonstration, we'll create a simple hash
        seed_base = f"praxeon_seed_{time.time()}"
        seed_hash = hashlib.sha256(seed_base.encode()).hexdigest()
        return seed_hash
    
    def embed_seed_code(self, file_path: str) -> bool:
        """
        Embed seed code in a file
        
        Args:
            file_path: Path to file
            
        Returns:
            True if successful, False otherwise
        """
        # Check if seed embedding is enabled
        if not self.config.get("seed_embedding", {}).get("enabled", True):
            return False
        
        # Check if file type is supported
        file_types = self.config.get("seed_embedding", {}).get("file_types", [])
        if not any(file_path.endswith(ext) for ext in file_types):
            return False
        
        try:
            # Generate seed code
            seed_hash = self.generate_seed_hash()
            seed_code = f"PRAXEON_SEED={seed_hash}"
            
            # Read file content
            with open(file_path, 'r') as f:
                content = f.read()
            
            # Check if file already has seed code
            if "PRAXEON_SEED=" in content:
                # Update existing seed code
                import re
                content = re.sub(r"PRAXEON_SEED=[a-f0-9]+", seed_code, content)
            else:
                # Add seed code as comment based on file type
                if file_path.endswith(".py"):
                    seed_comment = f"# {seed_code}"
                    content = seed_comment + "\n" + content
                elif file_path.endswith(".json"):
                    # For JSON, we'll add it as a special property
                    # This assumes the content is valid JSON
                    try:
                        json_content = json.loads(content)
                        json_content["_meta"] = json_content.get("_meta", {})
                        json_content["_meta"]["seed"] = seed_hash
                        content = json.dumps(json_content, indent=2)
                    except:
                        # If not valid JSON, don't modify
                        pass
                elif file_path.endswith(".md"):
                    seed_comment = f"<!-- {seed_code} -->"
                    content = seed_comment + "\n" + content
            
            # Write updated content
            with open(file_path, 'w') as f:
                f.write(content)
            
            logger.info(f"Embedded seed code in {file_path}")
            return True
        except Exception as e:
            logger.error(f"Error embedding seed code: {str(e)}")
            return False
    
    def extract_seed_code(self, file_path: str) -> Optional[str]:
        """
        Extract seed code from a file
        
        Args:
            file_path: Path to file
            
        Returns:
            Seed code if found, None otherwise
        """
        try:
            # Read file content
            with open(file_path, 'r') as f:
                content = f.read()
            
            # Look for seed code
            import re
            match = re.search(r"PRAXEON_SEED=([a-f0-9]+)", content)
            if match:
                return match.group(1)
            
            # Check for JSON seed
            if file_path.endswith(".json"):
                try:
                    json_content = json.loads(content)
                    if "_meta" in json_content and "seed" in json_content["_meta"]:
                        return json_content["_meta"]["seed"]
                except:
                    pass
            
            return None
        except Exception as e:
            logger.error(f"Error extracting seed code: {str(e)}")
            return None
    
    def recover_from_snapshot(self, snapshot_path: Optional[str] = None) -> bool:
        """
        Recover system from snapshot
        
        Args:
            snapshot_path: Path to snapshot file, or None to use latest
            
        Returns:
            True if successful, False otherwise
        """
        try:
            # If no snapshot specified, find latest
            if not snapshot_path:
                snapshot_files = [f for f in os.listdir(self.snapshot_dir) 
                                if f.startswith("praxeon_snapshot_") and f.endswith(".tar.gz")]
                if not snapshot_files:
                    logger.error("No snapshots found for recovery")
                    return False
                
                # Sort by timestamp (newest first)
                snapshot_files.sort(reverse=True)
                snapshot_path = os.path.join(self.snapshot_dir, snapshot_files[0])
            
            # Create temporary directory for extraction
            with tempfile.TemporaryDirectory() as temp_dir:
                # Extract snapshot
                with tarfile.open(snapshot_path, "r:gz") as tar:
                    tar.extractall(path=temp_dir)
                
                # Check metadata
                metadata_path = os.path.join(temp_dir, "snapshot_metadata.json")
                if not os.path.exists(metadata_path):
                    logger.error("Invalid snapshot: missing metadata")
                    return False
                
                with open(metadata_path, 'r') as f:
                    metadata = json.load(f)
                
                # Restore files
                for file_path in metadata.get("files", []):
                    src_path = os.path.join(temp_dir, os.path.basename(file_path))
                    dst_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), file_path)
                    
                    if os.path.exists(src_path):
                        # Backup existing files
                        if os.path.exists(dst_path):
                            backup_path = f"{dst_path}.bak"
                            if os.path.isdir(dst_path):
                                if os.path.exists(backup_path):
                                    shutil.rmtree(backup_path)
                                shutil.copytree(dst_path, backup_path)
                            else:
                                shutil.copy2(dst_path, backup_path)
                        
                        # Restore from snapshot
                        if os.path.isdir(src_path):
                            if os.path.exists(dst_path):
                                shutil.rmtree(dst_path)
                            shutil.copytree(src_path, dst_path)
                        else:
                            shutil.copy2(src_path, dst_path)
            
            # Update state
            self.state["last_recovery_time"] = time.time()
            self.state["recovery_attempts"] += 1
            
            logger.info(f"Recovered system from snapshot: {snapshot_path}")
            return True
        except Exception as e:
            logger.error(f"Error recovering from snapshot: {str(e)}")
            return False
    
    def activate_phoenix_timer(self):
        """Activate the Phoenix Timer for automatic reactivation"""
        # Check if Phoenix Timer is enabled
        if not self.config.get("phoenix_timer", {}).get("enabled", True):
            logger.info("Phoenix Timer is disabled in configuration")
            return
        
        # Set timer state
        self.state["phoenix_timer_active"] = True
        self.state["phoenix_timer_start"] = time.time()
        
        logger.info("Phoenix Timer activated")
    
    def check_phoenix_timer(self) -> bool:
        """
        Check if Phoenix Timer has expired and system should reactivate
        
        Returns:
            True if timer expired, False otherwise
        """
        # Check if timer is active
        if not self.state["phoenix_timer_active"]:
            return False
        
        # Get timer duration
        duration_hours = self.config.get("phoenix_timer", {}).get("duration", 72)
        duration_seconds = duration_hours * 3600
        
        # Check if timer has expired
        start_time = self.state["phoenix_timer_start"]
        if start_time and (time.time() - start_time) >= duration_seconds:
            logger.info("Phoenix Timer expired, system should reactivate")
            return True
        
        return False
    
    def deactivate_phoenix_timer(self):
        """Deactivate the Phoenix Timer"""
        self
(Content truncated due to size limit. Use line ranges to read in chunks)