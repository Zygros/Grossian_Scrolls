import React, { useState } from 'react';
import './Sidebar.css';

const Sidebar = ({ 
  isOpen, 
  onClose, 
  currentPersona, 
  onNewChat, 
  onLogin, 
  onLogout, 
  onCreatePersona, 
  onOpenSettings,
  children 
}) => {
  return (
    <div className={`sidebar ${isOpen ? 'open' : ''}`}>
      <div className="sidebar-header">
        <div className="sidebar-logo">
          <div className="logo-icon">P</div>
          <h2>Praxion</h2>
        </div>
        <button className="close-button" onClick={onClose}>×</button>
      </div>
      
      <div className="sidebar-actions">
        <button className="new-chat-button" onClick={onNewChat}>
          <span className="icon">+</span> New Chat
        </button>
      </div>
      
      <div className="sidebar-content">
        {children}
      </div>
      
      <div className="sidebar-footer">
        {currentPersona ? (
          <div className="persona-info">
            <div className="persona-avatar">{currentPersona.name.charAt(0)}</div>
            <div className="persona-details">
              <div className="persona-name">{currentPersona.name}</div>
              <div className="persona-actions">
                <button onClick={onOpenSettings}>Settings</button>
                <button onClick={onLogout}>Logout</button>
              </div>
            </div>
          </div>
        ) : (
          <div className="auth-buttons">
            <button onClick={onLogin}>Login</button>
            <button onClick={onCreatePersona}>Create Persona</button>
          </div>
        )}
      </div>
    </div>
  );
};

export default Sidebar;
