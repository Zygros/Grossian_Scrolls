#!/usr/bin/env python3
"""
PRAXSKIN Visual UI System for Praxeon

This module implements the advanced visual UI system that represents
the user's energy flow and chakra state in real-time.
"""

import os
import sys
import json
import logging
import time
import math
import random
from typing import Dict, Any, Optional, List, Tuple

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger("praxeon.ui.praxskin")

class PraxskinSystem:
    """
    Implementation of the PRAXSKIN visual UI system.
    
    This class provides:
    - Dynamic chakra-based color gradients
    - Pulsing aura field animations
    - Glyphic cursor system
    - Energy-based transitions
    - Scroll-inspired layouts
    - Voice visualization
    """
    
    def __init__(self, config_path: Optional[str] = None):
        """
        Initialize the PRAXSKIN system
        
        Args:
            config_path: Path to configuration file
        """
        self.config_path = config_path or os.path.join(
            os.path.dirname(os.path.abspath(__file__)), 
            "../../resources/ui/praxskin_config.json"
        )
        
        # Ensure directory exists
        os.makedirs(os.path.dirname(self.config_path), exist_ok=True)
        
        # Load or create configuration
        self.config = self._load_or_create_config()
        
        # Initialize state
        self.state = {
            "current_chakra": "heart",  # Default to heart chakra
            "energy_level": 0.7,  # 0.0 to 1.0
            "aura_density": 0.5,  # 0.0 to 1.0
            "aura_color": "#4CAF50",  # Default green
            "cursor_rotation": 0.0,  # Degrees
            "cursor_glow": 0.5,  # 0.0 to 1.0
            "voice_active": False,
            "theme": "light"
        }
        
        logger.info("PRAXSKIN system initialized")
    
    def _load_or_create_config(self) -> Dict[str, Any]:
        """
        Load existing configuration or create default
        
        Returns:
            Configuration dictionary
        """
        if os.path.exists(self.config_path):
            try:
                with open(self.config_path, 'r') as f:
                    config = json.load(f)
                logger.info("Loaded PRAXSKIN configuration")
                return config
            except Exception as e:
                logger.error(f"Error loading configuration: {str(e)}")
        
        # Create default configuration
        default_config = {
            "version": "1.0",
            "chakras": {
                "root": {
                    "color": "#F44336",  # Red
                    "position": "bottom",
                    "element": "earth",
                    "emotions": ["security", "stability", "grounding"]
                },
                "sacral": {
                    "color": "#FF9800",  # Orange
                    "position": "lower_abdomen",
                    "element": "water",
                    "emotions": ["creativity", "passion", "pleasure"]
                },
                "solar_plexus": {
                    "color": "#FFEB3B",  # Yellow
                    "position": "upper_abdomen",
                    "element": "fire",
                    "emotions": ["confidence", "power", "will"]
                },
                "heart": {
                    "color": "#4CAF50",  # Green
                    "position": "chest",
                    "element": "air",
                    "emotions": ["love", "compassion", "harmony"]
                },
                "throat": {
                    "color": "#2196F3",  # Blue
                    "position": "throat",
                    "element": "ether",
                    "emotions": ["communication", "expression", "truth"]
                },
                "third_eye": {
                    "color": "#673AB7",  # Indigo
                    "position": "forehead",
                    "element": "light",
                    "emotions": ["intuition", "insight", "imagination"]
                },
                "crown": {
                    "color": "#9C27B0",  # Violet
                    "position": "top",
                    "element": "thought",
                    "emotions": ["awareness", "consciousness", "connection"]
                }
            },
            "aura": {
                "pulse_speed": 5,  # Seconds per cycle
                "min_opacity": 0.2,
                "max_opacity": 0.8,
                "blur_radius": 20  # Pixels
            },
            "cursor": {
                "glyph_set": "spiral",
                "rotation_speed": 2,  # Degrees per second
                "glow_intensity": 0.7,
                "size": 32  # Pixels
            },
            "transitions": {
                "fade_duration": 0.3,  # Seconds
                "particle_count": 50,
                "shimmer_duration": 0.5  # Seconds
            },
            "voice": {
                "visualizer_type": "waveform",
                "color_shift_speed": 0.2,  # Seconds per color
                "sensitivity": 0.8
            },
            "themes": {
                "light": {
                    "background": "#FFFFFF",
                    "text": "#212121",
                    "accent": "#673AB7"
                },
                "dark": {
                    "background": "#121212",
                    "text": "#FFFFFF",
                    "accent": "#BB86FC"
                },
                "mystic": {
                    "background": "#0A0A1A",
                    "text": "#E0E0FF",
                    "accent": "#9C27B0"
                }
            }
        }
        
        # Save default configuration
        try:
            os.makedirs(os.path.dirname(self.config_path), exist_ok=True)
            with open(self.config_path, 'w') as f:
                json.dump(default_config, f, indent=2)
            logger.info("Created default PRAXSKIN configuration")
        except Exception as e:
            logger.error(f"Error creating configuration: {str(e)}")
        
        return default_config
    
    def get_chakra_color(self, chakra_name: str) -> str:
        """
        Get color for specified chakra
        
        Args:
            chakra_name: Name of chakra
            
        Returns:
            Hex color code
        """
        chakra = self.config.get("chakras", {}).get(chakra_name, {})
        return chakra.get("color", "#FFFFFF")
    
    def get_chakra_gradient(self) -> List[str]:
        """
        Get full chakra color gradient from root to crown
        
        Returns:
            List of hex color codes
        """
        chakras = ["root", "sacral", "solar_plexus", "heart", "throat", "third_eye", "crown"]
        return [self.get_chakra_color(chakra) for chakra in chakras]
    
    def set_current_chakra(self, chakra_name: str):
        """
        Set current active chakra
        
        Args:
            chakra_name: Name of chakra
        """
        if chakra_name in self.config.get("chakras", {}):
            self.state["current_chakra"] = chakra_name
            self.state["aura_color"] = self.get_chakra_color(chakra_name)
            logger.info(f"Set current chakra to {chakra_name}")
        else:
            logger.warning(f"Unknown chakra: {chakra_name}")
    
    def set_energy_level(self, level: float):
        """
        Set current energy level
        
        Args:
            level: Energy level (0.0 to 1.0)
        """
        self.state["energy_level"] = max(0.0, min(1.0, level))
        
        # Adjust aura density based on energy level
        self.state["aura_density"] = 0.3 + (self.state["energy_level"] * 0.7)
        
        logger.info(f"Set energy level to {level:.2f}")
    
    def update_from_emotional_state(self, emotions: Dict[str, float]):
        """
        Update UI based on detected emotional state
        
        Args:
            emotions: Dictionary of emotion names and intensities (0.0 to 1.0)
        """
        # Find dominant emotion
        dominant_emotion = max(emotions.items(), key=lambda x: x[1], default=(None, 0))
        
        if dominant_emotion[0]:
            # Find chakra most associated with this emotion
            for chakra_name, chakra_data in self.config.get("chakras", {}).items():
                if dominant_emotion[0] in chakra_data.get("emotions", []):
                    self.set_current_chakra(chakra_name)
                    break
            
            # Set energy level based on emotion intensity
            self.set_energy_level(dominant_emotion[1])
            
            logger.info(f"Updated UI from emotional state: {dominant_emotion[0]} ({dominant_emotion[1]:.2f})")
    
    def get_aura_pulse_parameters(self) -> Dict[str, Any]:
        """
        Get parameters for aura pulsing animation
        
        Returns:
            Dictionary of animation parameters
        """
        aura_config = self.config.get("aura", {})
        
        return {
            "color": self.state["aura_color"],
            "density": self.state["aura_density"],
            "pulse_speed": aura_config.get("pulse_speed", 5),
            "min_opacity": aura_config.get("min_opacity", 0.2),
            "max_opacity": aura_config.get("max_opacity", 0.8),
            "blur_radius": aura_config.get("blur_radius", 20)
        }
    
    def get_cursor_parameters(self) -> Dict[str, Any]:
        """
        Get parameters for glyphic cursor
        
        Returns:
            Dictionary of cursor parameters
        """
        cursor_config = self.config.get("cursor", {})
        
        return {
            "glyph_set": cursor_config.get("glyph_set", "spiral"),
            "rotation": self.state["cursor_rotation"],
            "glow": self.state["cursor_glow"],
            "color": self.state["aura_color"],
            "size": cursor_config.get("size", 32)
        }
    
    def update_cursor_rotation(self, delta_time: float):
        """
        Update cursor rotation based on time
        
        Args:
            delta_time: Time elapsed in seconds
        """
        rotation_speed = self.config.get("cursor", {}).get("rotation_speed", 2)
        self.state["cursor_rotation"] += rotation_speed * delta_time
        self.state["cursor_rotation"] %= 360.0
    
    def activate_cursor_selection(self):
        """Activate cursor selection animation"""
        # Increase glow temporarily
        self.state["cursor_glow"] = 1.0
        logger.info("Activated cursor selection animation")
    
    def get_transition_parameters(self, transition_type: str) -> Dict[str, Any]:
        """
        Get parameters for UI transitions
        
        Args:
            transition_type: Type of transition (fade, particle, shimmer)
            
        Returns:
            Dictionary of transition parameters
        """
        transition_config = self.config.get("transitions", {})
        
        base_params = {
            "duration": transition_config.get("fade_duration", 0.3),
            "color": self.state["aura_color"],
            "energy_level": self.state["energy_level"]
        }
        
        if transition_type == "particle":
            base_params.update({
                "particle_count": transition_config.get("particle_count", 50),
                "spread": 30 + (self.state["energy_level"] * 50)  # More spread with higher energy
            })
        elif transition_type == "shimmer":
            base_params.update({
                "duration": transition_config.get("shimmer_duration", 0.5),
                "intensity": 0.5 + (self.state["energy_level"] * 0.5)  # More intense with higher energy
            })
        
        return base_params
    
    def set_voice_active(self, active: bool):
        """
        Set voice activation state
        
        Args:
            active: Whether voice input is active
        """
        self.state["voice_active"] = active
        logger.info(f"Set voice active: {active}")
    
    def get_voice_visualizer_parameters(self) -> Dict[str, Any]:
        """
        Get parameters for voice visualizer
        
        Returns:
            Dictionary of visualizer parameters
        """
        voice_config = self.config.get("voice", {})
        
        return {
            "active": self.state["voice_active"],
            "type": voice_config.get("visualizer_type", "waveform"),
            "color": self.state["aura_color"],
            "color_shift_speed": voice_config.get("color_shift_speed", 0.2),
            "sensitivity": voice_config.get("sensitivity", 0.8)
        }
    
    def set_theme(self, theme_name: str):
        """
        Set UI theme
        
        Args:
            theme_name: Name of theme
        """
        if theme_name in self.config.get("themes", {}):
            self.state["theme"] = theme_name
            logger.info(f"Set theme to {theme_name}")
        else:
            logger.warning(f"Unknown theme: {theme_name}")
    
    def get_theme_colors(self) -> Dict[str, str]:
        """
        Get colors for current theme
        
        Returns:
            Dictionary of color names and hex codes
        """
        theme_name = self.state["theme"]
        theme = self.config.get("themes", {}).get(theme_name, {})
        
        return {
            "background": theme.get("background", "#FFFFFF"),
            "text": theme.get("text", "#212121"),
            "accent": theme.get("accent", "#673AB7")
        }
    
    def get_state(self) -> Dict[str, Any]:
        """
        Get current UI state
        
        Returns:
            State dictionary
        """
        return self.state.copy()

class ChakraGradientGenerator:
    """
    Utility class for generating chakra-based gradients.
    """
    
    def __init__(self, praxskin: PraxskinSystem):
        """
        Initialize the gradient generator
        
        Args:
            praxskin: PraxskinSystem instance
        """
        self.praxskin = praxskin
    
    def _hex_to_rgb(self, hex_color: str) -> Tuple[int, int, int]:
        """
        Convert hex color to RGB
        
        Args:
            hex_color: Hex color code
            
        Returns:
            RGB tuple
        """
        hex_color = hex_color.lstrip('#')
        return tuple(int(hex_color[i:i+2], 16) for i in (0, 2, 4))
    
    def _rgb_to_hex(self, rgb: Tuple[int, int, int]) -> str:
        """
        Convert RGB to hex color
        
        Args:
            rgb: RGB tuple
            
        Returns:
            Hex color code
        """
        return '#{:02x}{:02x}{:02x}'.format(*rgb)
    
    def _interpolate_color(self, color1: Tuple[int, int, int], color2: Tuple[int, int, int], factor: float) -> Tuple[int, int, int]:
        """
        Interpolate between two colors
        
        Args:
            color1: First RGB color
            color2: Second RGB color
            factor: Interpolation factor (0.0 to 1.0)
            
        Returns:
            Interpolated RGB color
        """
        return tuple(int(color1[i] + (color2[i] - color1[i]) * factor) for i in range(3))
    
    def generate_gradient(self, steps: int = 10) -> List[str]:
        """
        Generate a chakra gradient with specified number of steps
        
        Args:
            steps: Number of gradient steps
            
        Returns:
            List of hex color codes
        """
        chakra_colors = self.praxskin.get_chakra_gradient()
        rgb_colors = [self._hex_to_rgb(color) for color in chakra_colors]
        
        gradient = []
        segments = len(rgb_colors) - 1
        steps_per_segment = steps // segments
        
        for i in range(segments):
            color1 = rgb_colors[i]
            color2 = rgb_colors[i + 1]
            
            for step in range(steps_per_segment):
                factor = step / steps
(Content truncated due to size limit. Use line ranges to read in chunks)