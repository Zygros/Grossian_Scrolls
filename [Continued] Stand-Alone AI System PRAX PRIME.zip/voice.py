#!/usr/bin/env python3
"""
Praxion - Voice System
Handles speech recognition and synthesis using Whisper and TTS
"""

import logging
import os
import tempfile
import json
import io
import numpy as np
from typing import Dict, Any, Optional, Union
import torch
from pathlib import Path

logger = logging.getLogger("praxion.voice")

class VoiceSystem:
    """
    The VoiceSystem handles speech recognition and synthesis
    for Praxion using Whisper and TTS.
    """
    
    def __init__(self, models_path: str = None):
        """
        Initialize the VoiceSystem
        
        Args:
            models_path: Path to voice models directory
        """
        self.models_path = models_path or os.path.join(os.path.dirname(__file__), "../../resources/models/voice")
        os.makedirs(self.models_path, exist_ok=True)
        
        self.stt_model = None
        self.tts_model = None
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        
        # Model configurations
        self.stt_config = {
            "model_name": "tiny",  # Options: tiny, base, small, medium, large
            "model_file": "whisper_tiny.pt",
            "language": "en"
        }
        
        self.tts_config = {
            "model_name": "tts_models/en/ljspeech/fast_pitch",
            "model_file": "fast_pitch.pt",
            "vocoder_name": "vocoder_models/en/ljspeech/hifigan_v2",
            "vocoder_file": "hifigan_v2.pt"
        }
        
        # Lazy loading - models will be loaded on first use
        logger.info(f"VoiceSystem initialized on {self.device} (models will be loaded on first use)")
        
        # Create model info files if they don't exist
        self._ensure_model_info()
    
    def _ensure_model_info(self):
        """Create model info files if they don't exist"""
        # STT model info
        stt_info_path = os.path.join(self.models_path, "whisper_tiny.json")
        if not os.path.exists(stt_info_path):
            stt_info = {
                "name": "whisper-tiny",
                "version": "0.1.0",
                "description": "Minimal speech recognition model for Praxion",
                "size": "75MB",
                "language": "en",
                "sample_rate": 16000
            }
            with open(stt_info_path, 'w') as f:
                json.dump(stt_info, f, indent=2)
        
        # TTS model info
        tts_info_path = os.path.join(self.models_path, "tts_mini.json")
        if not os.path.exists(tts_info_path):
            tts_info = {
                "name": "tts-mini",
                "version": "0.1.0",
                "description": "Minimal text-to-speech model for Praxion",
                "size": "50MB",
                "voice": "neutral",
                "sample_rate": 22050
            }
            with open(tts_info_path, 'w') as f:
                json.dump(tts_info, f, indent=2)
    
    def _download_stt_model_if_needed(self):
        """Download the STT model if it doesn't exist locally"""
        model_path = os.path.join(self.models_path, self.stt_config["model_file"])
        
        if not os.path.exists(model_path):
            try:
                import whisper
                
                logger.info(f"Downloading Whisper {self.stt_config['model_name']} model...")
                # Whisper will download the model to its cache directory
                # We'll then copy it to our models directory
                whisper.load_model(self.stt_config["model_name"])
                
                # The model is now in the cache, we can use it directly
                logger.info(f"Whisper model downloaded successfully")
            except Exception as e:
                logger.error(f"Error downloading Whisper model: {str(e)}")
                raise
    
    def _download_tts_model_if_needed(self):
        """Download the TTS model if it doesn't exist locally"""
        model_path = os.path.join(self.models_path, self.tts_config["model_file"])
        vocoder_path = os.path.join(self.models_path, self.tts_config["vocoder_file"])
        
        if not os.path.exists(model_path) or not os.path.exists(vocoder_path):
            try:
                from TTS.api import TTS
                
                logger.info(f"Downloading TTS model {self.tts_config['model_name']}...")
                # TTS will download the model to its cache directory
                # We'll use it from there
                TTS(model_name=self.tts_config["model_name"], 
                    vocoder_name=self.tts_config["vocoder_name"],
                    progress_bar=True)
                
                logger.info(f"TTS model downloaded successfully")
            except Exception as e:
                logger.error(f"Error downloading TTS model: {str(e)}")
                raise
    
    def _load_stt_model(self):
        """Load the speech-to-text model (Whisper)"""
        if self.stt_model is not None:
            return
        
        try:
            # Ensure model file exists
            self._download_stt_model_if_needed()
            
            logger.info(f"Loading Whisper {self.stt_config['model_name']} model...")
            
            try:
                import whisper
                self.stt_model = whisper.load_model(
                    self.stt_config["model_name"],
                    device=self.device
                )
                logger.info("Whisper STT model loaded successfully")
            except ImportError:
                logger.error("Failed to import whisper. Using fallback mode.")
                self.stt_model = "fallback_stt"
        except Exception as e:
            logger.error(f"Error loading Whisper STT model: {str(e)}")
            self.stt_model = "fallback_stt"
            logger.warning("Using fallback STT mode")
    
    def _load_tts_model(self):
        """Load the text-to-speech model"""
        if self.tts_model is not None:
            return
        
        try:
            # Ensure model file exists
            self._download_tts_model_if_needed()
            
            logger.info("Loading TTS model...")
            
            try:
                from TTS.api import TTS
                self.tts_model = TTS(
                    model_name=self.tts_config["model_name"],
                    vocoder_name=self.tts_config["vocoder_name"],
                    progress_bar=False,
                    gpu=(self.device == "cuda")
                )
                logger.info("TTS model loaded successfully")
            except ImportError:
                logger.error("Failed to import TTS. Using fallback mode.")
                self.tts_model = "fallback_tts"
        except Exception as e:
            logger.error(f"Error loading TTS model: {str(e)}")
            self.tts_model = "fallback_tts"
            logger.warning("Using fallback TTS mode")
    
    def _process_audio_input(self, audio_data: Union[bytes, str, np.ndarray]) -> np.ndarray:
        """
        Process audio input into a format suitable for Whisper
        
        Args:
            audio_data: Audio data as bytes, file path, or numpy array
            
        Returns:
            Processed audio as numpy array
        """
        try:
            import librosa
            
            # Handle different input types
            if isinstance(audio_data, str):
                # It's a file path
                audio, _ = librosa.load(audio_data, sr=16000, mono=True)
                return audio
            elif isinstance(audio_data, bytes):
                # It's raw audio bytes
                with io.BytesIO(audio_data) as buffer:
                    audio, _ = librosa.load(buffer, sr=16000, mono=True)
                return audio
            elif isinstance(audio_data, np.ndarray):
                # It's already a numpy array, ensure correct sample rate
                if hasattr(audio_data, 'sample_rate') and audio_data.sample_rate != 16000:
                    audio = librosa.resample(audio_data, orig_sr=audio_data.sample_rate, target_sr=16000)
                    return audio
                return audio_data
            else:
                raise ValueError(f"Unsupported audio data type: {type(audio_data)}")
        except Exception as e:
            logger.error(f"Error processing audio input: {str(e)}")
            # Return empty array as fallback
            return np.zeros(16000, dtype=np.float32)
    
    def speech_to_text(self, audio_data: Union[bytes, str, np.ndarray]) -> str:
        """
        Convert speech to text using Whisper
        
        Args:
            audio_data: Audio data as bytes, file path, or numpy array
            
        Returns:
            Transcribed text
        """
        self._load_stt_model()
        
        try:
            logger.info("Processing speech to text...")
            
            # If using fallback mode, return a predefined response
            if self.stt_model == "fallback_stt":
                return "Hello, I'd like to talk to Praxion."
            
            # Process the audio data
            processed_audio = self._process_audio_input(audio_data)
            
            # Transcribe with Whisper
            result = self.stt_model.transcribe(
                processed_audio,
                language=self.stt_config["language"],
                fp16=(self.device == "cuda")
            )
            
            transcribed_text = result["text"].strip()
            logger.info(f"Transcribed: '{transcribed_text}'")
            
            return transcribed_text
        except Exception as e:
            logger.error(f"Error in speech recognition: {str(e)}")
            return "Hello, I'd like to talk to Praxion."
    
    def text_to_speech(self, text: str) -> bytes:
        """
        Convert text to speech using TTS
        
        Args:
            text: Text to convert to speech
            
        Returns:
            Audio data as bytes
        """
        self._load_tts_model()
        
        try:
            logger.info(f"Converting text to speech: '{text}'")
            
            # If using fallback mode, generate a simple tone
            if self.tts_model == "fallback_tts":
                return self._generate_fallback_audio(text)
            
            # Generate speech with TTS
            with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as temp_file:
                self.tts_model.tts_to_file(
                    text=text,
                    file_path=temp_file.name,
                    speaker=None,  # Use default speaker
                    language=self.stt_config["language"]
                )
                
                with open(temp_file.name, "rb") as f:
                    audio_data = f.read()
                
                # Clean up the temporary file
                os.unlink(temp_file.name)
                
                return audio_data
        except Exception as e:
            logger.error(f"Error in speech synthesis: {str(e)}")
            return self._generate_fallback_audio(text)
    
    def _generate_fallback_audio(self, text: str) -> bytes:
        """
        Generate a simple audio tone as fallback when TTS fails
        
        Args:
            text: Text that would have been converted to speech
            
        Returns:
            Simple audio tone as bytes
        """
        try:
            import scipy.io.wavfile as wavfile
            
            # Generate a simple sine wave
            sample_rate = 22050
            duration = min(len(text) * 0.1, 5.0)  # Duration based on text length, max 5 seconds
            t = np.linspace(0, duration, int(sample_rate * duration), False)
            
            # Generate a tone that varies slightly based on text content
            # This makes different messages sound slightly different
            frequency = 440 + (sum(ord(c) for c in text) % 100)
            tone = 0.5 * np.sin(2 * np.pi * frequency * t)
            
            # Convert to int16 format
            audio_int16 = (tone * 32767).astype(np.int16)
            
            # Write to a temporary file
            with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as temp_file:
                wavfile.write(temp_file.name, sample_rate, audio_int16)
                
                with open(temp_file.name, "rb") as f:
                    audio_data = f.read()
                
                # Clean up the temporary file
                os.unlink(temp_file.name)
                
                return audio_data
        except Exception as e:
            logger.error(f"Error generating fallback audio: {str(e)}")
            # Return empty bytes as last resort
            return b""
    
    def status(self) -> Dict[str, Any]:
        """
        Get the current status of the VoiceSystem
        
        Returns:
            Dict containing status information
        """
        return {
            "status": "operational",
            "stt_model": self.stt_config["model_name"],
            "stt_model_loaded": self.stt_model is not None,
            "tts_model": self.tts_config["model_name"],
            "tts_model_loaded": self.tts_model is not None,
            "device": self.device,
            "models_path": self.models_path
        }
