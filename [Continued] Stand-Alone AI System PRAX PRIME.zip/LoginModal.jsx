import React, { useState } from 'react';
import './LoginModal.css';

const LoginModal = ({ onClose, onLogin, personas }) => {
  const [selectedPersona, setSelectedPersona] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    
    // Validate inputs
    if (!selectedPersona) {
      setError('Please select a persona');
      return;
    }
    
    // Check if persona requires password
    const persona = personas.find(p => p.id === selectedPersona);
    if (persona && persona.auth.type === 'password' && !password) {
      setError('Please enter a password');
      return;
    }
    
    // Login
    onLogin(selectedPersona, password);
  };

  return (
    <div className="modal-overlay">
      <div className="modal-container">
        <div className="modal-header">
          <h2>Login to Praxion</h2>
          <button className="close-button" onClick={onClose}>×</button>
        </div>
        
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label htmlFor="persona-select">Select Persona</label>
            <select
              id="persona-select"
              value={selectedPersona}
              onChange={(e) => setSelectedPersona(e.target.value)}
              autoFocus
            >
              <option value="">-- Select a persona --</option>
              {personas.map(persona => (
                <option key={persona.id} value={persona.id}>
                  {persona.name} {persona.auth.type === 'password' ? '(Password protected)' : ''}
                </option>
              ))}
            </select>
          </div>
          
          {selectedPersona && personas.find(p => p.id === selectedPersona)?.auth.type === 'password' && (
            <div className="form-group">
              <label htmlFor="password">Password</label>
              <input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter password"
              />
            </div>
          )}
          
          {error && <div className="error-message">{error}</div>}
          
          <div className="form-actions">
            <button type="button" className="cancel-button" onClick={onClose}>Cancel</button>
            <button type="submit" className="login-button">Login</button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default LoginModal;
