#!/usr/bin/env python3
"""
Praxion - Persona Lock System
Manages user authentication and persona security with raw-auth protocol
"""

import logging
import os
import json
import time
import hashlib
import base64
import secrets
from typing import Dict, Any, List, Optional, Tuple
from pathlib import Path
from datetime import datetime, timedelta

logger = logging.getLogger("praxion.persona_lock")

class PersonaLockSystem:
    """
    The PersonaLockSystem manages user authentication, persona security,
    and access control using the raw-auth protocol for Praxion.
    """
    
    def __init__(self, storage_path: str = None):
        """
        Initialize the PersonaLockSystem
        
        Args:
            storage_path: Path to persona storage directory
        """
        self.storage_path = storage_path or os.path.join(os.path.dirname(__file__), "../../resources/persona")
        os.makedirs(self.storage_path, exist_ok=True)
        
        self.current_persona = None
        self.auth_tokens = {}
        self.session_expiry = {}
        self.session_duration = 24 * 60 * 60  # 24 hours in seconds
        
        # Load existing personas
        self.personas = self._load_personas()
        
        # Create default persona if none exist
        if not self.personas:
            self._create_default_persona()
        
        logger.info(f"PersonaLockSystem initialized with {len(self.personas)} personas")
    
    def _load_personas(self) -> Dict[str, Dict[str, Any]]:
        """
        Load existing personas from storage
        
        Returns:
            Dictionary of personas
        """
        personas_file = os.path.join(self.storage_path, "personas.json")
        
        if os.path.exists(personas_file):
            try:
                with open(personas_file, 'r') as f:
                    personas = json.load(f)
                logger.info(f"Loaded {len(personas)} personas from storage")
                return personas
            except Exception as e:
                logger.error(f"Error loading personas: {str(e)}")
                return {}
        else:
            logger.info("No personas file found, starting with empty personas")
            return {}
    
    def _save_personas(self):
        """Save personas to storage"""
        personas_file = os.path.join(self.storage_path, "personas.json")
        
        try:
            with open(personas_file, 'w') as f:
                json.dump(self.personas, f, indent=2)
            logger.info(f"Saved {len(self.personas)} personas to storage")
        except Exception as e:
            logger.error(f"Error saving personas: {str(e)}")
    
    def _create_default_persona(self):
        """Create a default persona if none exist"""
        default_persona = {
            "id": "default",
            "name": "Default",
            "created_at": datetime.now().isoformat(),
            "last_accessed": datetime.now().isoformat(),
            "auth": {
                "type": "none",
                "hash": None,
                "salt": None
            },
            "settings": {
                "voice": {
                    "enabled": True,
                    "volume": 0.8,
                    "rate": 1.0
                },
                "theme": "light",
                "privacy_level": "standard"
            },
            "metadata": {
                "description": "Default persona for Praxion",
                "icon": "default",
                "color": "#3498db"
            }
        }
        
        self.personas["default"] = default_persona
        self._save_personas()
        logger.info("Created default persona")
    
    def _generate_auth_token(self, persona_id: str) -> str:
        """
        Generate an authentication token for a persona
        
        Args:
            persona_id: ID of the persona
            
        Returns:
            Authentication token
        """
        token = secrets.token_hex(32)
        self.auth_tokens[token] = persona_id
        self.session_expiry[token] = time.time() + self.session_duration
        return token
    
    def _hash_password(self, password: str, salt: Optional[str] = None) -> Tuple[str, str]:
        """
        Hash a password using PBKDF2 with SHA-256
        
        Args:
            password: Password to hash
            salt: Optional salt, generated if not provided
            
        Returns:
            Tuple of (password_hash, salt)
        """
        if salt is None:
            salt = secrets.token_hex(16)
        
        # Use PBKDF2 with SHA-256, 100,000 iterations
        key = hashlib.pbkdf2_hmac(
            'sha256',
            password.encode('utf-8'),
            salt.encode('utf-8'),
            100000
        )
        
        # Convert binary hash to hex string
        password_hash = key.hex()
        
        return password_hash, salt
    
    def create_persona(self, name: str, password: Optional[str] = None) -> Dict[str, Any]:
        """
        Create a new persona
        
        Args:
            name: Name of the persona
            password: Optional password for the persona
            
        Returns:
            Newly created persona
        """
        # Generate a unique ID
        persona_id = f"persona_{int(time.time())}_{secrets.token_hex(4)}"
        
        # Set up authentication
        auth = {
            "type": "none",
            "hash": None,
            "salt": None
        }
        
        if password:
            password_hash, salt = self._hash_password(password)
            auth = {
                "type": "password",
                "hash": password_hash,
                "salt": salt
            }
        
        # Create the persona
        persona = {
            "id": persona_id,
            "name": name,
            "created_at": datetime.now().isoformat(),
            "last_accessed": datetime.now().isoformat(),
            "auth": auth,
            "settings": {
                "voice": {
                    "enabled": True,
                    "volume": 0.8,
                    "rate": 1.0
                },
                "theme": "light",
                "privacy_level": "standard"
            },
            "metadata": {
                "description": f"Persona for {name}",
                "icon": "user",
                "color": "#3498db"
            }
        }
        
        # Save the persona
        self.personas[persona_id] = persona
        self._save_personas()
        
        logger.info(f"Created new persona: {name} ({persona_id})")
        return persona
    
    def authenticate(self, persona_id: str, password: Optional[str] = None) -> Optional[str]:
        """
        Authenticate a persona
        
        Args:
            persona_id: ID of the persona
            password: Password for the persona (if required)
            
        Returns:
            Authentication token if successful, None otherwise
        """
        # Check if persona exists
        if persona_id not in self.personas:
            logger.warning(f"Authentication failed: Persona {persona_id} not found")
            return None
        
        persona = self.personas[persona_id]
        auth_type = persona["auth"]["type"]
        
        # Check authentication
        if auth_type == "none":
            # No authentication required
            pass
        elif auth_type == "password":
            if not password:
                logger.warning(f"Authentication failed: Password required for {persona_id}")
                return None
            
            # Verify password
            stored_hash = persona["auth"]["hash"]
            salt = persona["auth"]["salt"]
            
            password_hash, _ = self._hash_password(password, salt)
            
            if password_hash != stored_hash:
                logger.warning(f"Authentication failed: Invalid password for {persona_id}")
                return None
        else:
            logger.warning(f"Authentication failed: Unknown auth type {auth_type}")
            return None
        
        # Update last accessed time
        persona["last_accessed"] = datetime.now().isoformat()
        self._save_personas()
        
        # Generate and return auth token
        token = self._generate_auth_token(persona_id)
        self.current_persona = persona_id
        
        logger.info(f"Authentication successful for {persona_id}")
        return token
    
    def validate_token(self, token: str) -> bool:
        """
        Validate an authentication token
        
        Args:
            token: Authentication token
            
        Returns:
            True if token is valid, False otherwise
        """
        if token not in self.auth_tokens:
            return False
        
        # Check if token has expired
        if time.time() > self.session_expiry[token]:
            # Token expired, remove it
            persona_id = self.auth_tokens[token]
            del self.auth_tokens[token]
            del self.session_expiry[token]
            
            logger.info(f"Token expired for {persona_id}")
            return False
        
        # Extend token expiry
        self.session_expiry[token] = time.time() + self.session_duration
        
        return True
    
    def get_current_persona(self) -> Optional[Dict[str, Any]]:
        """
        Get the current authenticated persona
        
        Returns:
            Current persona if authenticated, None otherwise
        """
        if self.current_persona is None:
            return None
        
        return self.personas.get(self.current_persona)
    
    def get_persona(self, persona_id: str) -> Optional[Dict[str, Any]]:
        """
        Get a persona by ID
        
        Args:
            persona_id: ID of the persona
            
        Returns:
            Persona if found, None otherwise
        """
        return self.personas.get(persona_id)
    
    def list_personas(self) -> List[Dict[str, Any]]:
        """
        List all personas (without sensitive auth information)
        
        Returns:
            List of personas
        """
        result = []
        
        for persona_id, persona in self.personas.items():
            # Create a copy without sensitive auth information
            persona_copy = persona.copy()
            persona_copy["auth"] = {"type": persona["auth"]["type"]}
            result.append(persona_copy)
        
        return result
    
    def update_persona(self, persona_id: str, updates: Dict[str, Any], token: str) -> Optional[Dict[str, Any]]:
        """
        Update a persona
        
        Args:
            persona_id: ID of the persona
            updates: Dictionary of updates to apply
            token: Authentication token
            
        Returns:
            Updated persona if successful, None otherwise
        """
        # Validate token
        if not self.validate_token(token):
            logger.warning(f"Update failed: Invalid token")
            return None
        
        # Check if token is for the correct persona
        if self.auth_tokens[token] != persona_id:
            logger.warning(f"Update failed: Token not authorized for {persona_id}")
            return None
        
        # Check if persona exists
        if persona_id not in self.personas:
            logger.warning(f"Update failed: Persona {persona_id} not found")
            return None
        
        persona = self.personas[persona_id]
        
        # Apply updates
        if "name" in updates:
            persona["name"] = updates["name"]
        
        if "settings" in updates:
            for key, value in updates["settings"].items():
                if key in persona["settings"]:
                    if isinstance(persona["settings"][key], dict) and isinstance(value, dict):
                        # Merge dictionaries
                        persona["settings"][key].update(value)
                    else:
                        # Replace value
                        persona["settings"][key] = value
        
        if "metadata" in updates:
            for key, value in updates["metadata"].items():
                if key in persona["metadata"]:
                    persona["metadata"][key] = value
        
        # Save changes
        self._save_personas()
        
        logger.info(f"Updated persona {persona_id}")
        return persona
    
    def change_password(self, persona_id: str, current_password: str, new_password: str, token: str) -> bool:
        """
        Change a persona's password
        
        Args:
            persona_id: ID of the persona
            current_password: Current password
            new_password: New password
            token: Authentication token
            
        Returns:
            True if successful, False otherwise
        """
        # Validate token
        if not self.validate_token(token):
            logger.warning(f"Password change failed: Invalid token")
            return False
        
        # Check if token is for the correct persona
        if self.auth_tokens[token] != persona_id:
            logger.warning(f"Password change failed: Token not authorized for {persona_id}")
            return False
        
        # Check if persona exists
        if persona_id not in self.personas:
            logger.warning(f"Password change failed: Persona {persona_id} not found")
            return False
        
        persona = self.personas[persona_id]
        
        # Verify current password if auth type is password
        if persona["auth"]["type"] == "password":
            stored_hash = persona["auth"]["hash"]
            salt = persona["auth"]["salt"]
            
            password_hash, _ = self._hash_password(current_password, salt)
            
            if password_hash != stored_hash:
                logger.warning(f"Password change failed: Invalid current password for {persona_id}")
                return False
        
        # Set new password
        password_hash, salt = self._hash_password(new_password)
        persona["auth"] = {
            "type": "password",
            "hash": password_hash,
            "salt": salt
        }
        
        # Save changes
        self._save_personas()
        
        logger.info(f"Changed password for {persona_id}")
        return True
    
    def logout(self, token: str) -> bool:
        """
        Log out a persona
        
        Args:
            token: Authentication token
            
        Returns:
            True if successful, False otherwise
        """
        if token not in self.auth_tokens:
            return False
        
        persona_id = self.auth_tokens[token]
        
        # Remove token
        del self.auth_tokens[token]
        del self.session_expiry[token]
        
        # Clear current persona if it matches
        if self.current_persona == persona_id:
            self.current_persona = None
        
        logger.info(f"Logged out {persona_id}")
        return True
    
    def delete_persona(self, persona_id: str, password: Optional[str] = None, token: str = None) -> bool:
        """
        Delete a persona
        
        Args:
            persona_id: ID of the persona
            password: Password for the persona (if required)
            token: Authentication token (alternative to password)
            
        Returns:
            True if successful, False otherwise
        """
        # Check if persona exists
        if persona_id not in self.personas:
            logger.warning(f"Delete failed: Persona {persona_id} not found")
            return False
        
        persona = self.personas[persona_id]
        
        # Authenticate
        authenticated = False
        
        if token and token in self.auth_tokens:
            if self.auth_tokens[token] == persona_id:
                authenticated = True
        

(Content truncated due to size limit. Use line ranges to read in chunks)