#!/usr/bin/env python3
"""
Praxion - Integration Test Suite
Tests all modules and features of Praxion
"""

import os
import sys
import logging
import argparse
import unittest
import json
import time
import requests
import subprocess
import signal
import threading
from pathlib import Path

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger("praxion.test")

# Define paths
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
ROOT_DIR = os.path.abspath(os.path.join(SCRIPT_DIR, ".."))
SRC_DIR = os.path.join(ROOT_DIR, "src")
BACKEND_DIR = os.path.join(SRC_DIR, "backend")
RESOURCES_DIR = os.path.join(ROOT_DIR, "resources")

# API URL
API_URL = "http://localhost:8000"

class PraxionServer:
    """Class to manage Praxion server for testing"""
    
    def __init__(self):
        self.process = None
    
    def start(self):
        """Start the Praxion server"""
        if self.process:
            logger.warning("Server already running")
            return
        
        # Start server
        cmd = [sys.executable, "-m", "uvicorn", "src.backend.main:app", "--host", "0.0.0.0", "--port", "8000"]
        self.process = subprocess.Popen(
            cmd,
            cwd=ROOT_DIR,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            preexec_fn=os.setsid
        )
        
        # Wait for server to start
        for _ in range(30):
            try:
                response = requests.get(f"{API_URL}/")
                if response.status_code == 200:
                    logger.info("Server started successfully")
                    return True
            except requests.exceptions.ConnectionError:
                pass
            time.sleep(1)
        
        logger.error("Failed to start server")
        self.stop()
        return False
    
    def stop(self):
        """Stop the Praxion server"""
        if not self.process:
            return
        
        # Kill process group
        try:
            os.killpg(os.getpgid(self.process.pid), signal.SIGTERM)
            self.process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            os.killpg(os.getpgid(self.process.pid), signal.SIGKILL)
        except Exception as e:
            logger.error(f"Error stopping server: {str(e)}")
        
        self.process = None
        logger.info("Server stopped")

class TestPraxionBackend(unittest.TestCase):
    """Test Praxion backend API"""
    
    @classmethod
    def setUpClass(cls):
        """Set up test class"""
        cls.server = PraxionServer()
        cls.server.start()
    
    @classmethod
    def tearDownClass(cls):
        """Tear down test class"""
        cls.server.stop()
    
    def test_01_root_endpoint(self):
        """Test root endpoint"""
        response = requests.get(f"{API_URL}/")
        self.assertEqual(response.status_code, 200)
        self.assertIn("message", response.json())
        self.assertIn("Hello, Praxion", response.json()["message"])
    
    def test_02_status_endpoint(self):
        """Test status endpoint"""
        response = requests.get(f"{API_URL}/status")
        self.assertEqual(response.status_code, 200)
        self.assertIn("status", response.json())
        self.assertEqual(response.json()["status"], "operational")
        
        # Check all modules
        self.assertIn("llm", response.json())
        self.assertIn("voice", response.json())
        self.assertIn("persona", response.json())
        self.assertIn("infinite_scroll", response.json())
    
    def test_03_chat_endpoint(self):
        """Test chat endpoint"""
        response = requests.post(f"{API_URL}/chat", params={"message": "Hello, Praxion!"})
        self.assertEqual(response.status_code, 200)
        self.assertIn("response", response.json())
        self.assertIn("session_id", response.json())
    
    def test_04_persona_endpoints(self):
        """Test persona endpoints"""
        # List personas
        response = requests.get(f"{API_URL}/personas")
        self.assertEqual(response.status_code, 200)
        self.assertIsInstance(response.json(), list)
        
        # Create persona
        response = requests.post(f"{API_URL}/personas", json={"name": "Test Persona"})
        self.assertEqual(response.status_code, 200)
        self.assertIn("id", response.json())
        persona_id = response.json()["id"]
        
        # Login
        response = requests.post(f"{API_URL}/personas/login", params={"persona_id": persona_id})
        self.assertEqual(response.status_code, 200)
        self.assertIn("token", response.json())
        token = response.json()["token"]
        
        # Get current persona
        response = requests.get(
            f"{API_URL}/personas/current",
            headers={"Authorization": f"Bearer {token}"}
        )
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()["id"], persona_id)
        
        # Update persona
        response = requests.put(
            f"{API_URL}/personas/{persona_id}",
            json={"name": "Updated Test Persona"},
            headers={"Authorization": f"Bearer {token}"}
        )
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()["name"], "Updated Test Persona")
        
        # Logout
        response = requests.post(
            f"{API_URL}/personas/logout",
            headers={"Authorization": f"Bearer {token}"}
        )
        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.json()["success"])
    
    def test_05_session_endpoints(self):
        """Test session endpoints"""
        # Create persona for testing
        response = requests.post(f"{API_URL}/personas", json={"name": "Session Test Persona"})
        self.assertEqual(response.status_code, 200)
        persona_id = response.json()["id"]
        
        # Login
        response = requests.post(f"{API_URL}/personas/login", params={"persona_id": persona_id})
        self.assertEqual(response.status_code, 200)
        token = response.json()["token"]
        
        # Create session
        response = requests.post(
            f"{API_URL}/sessions",
            json={"title": "Test Session"},
            headers={"Authorization": f"Bearer {token}"}
        )
        self.assertEqual(response.status_code, 200)
        self.assertIn("session_id", response.json())
        session_id = response.json()["session_id"]
        
        # List sessions
        response = requests.get(f"{API_URL}/sessions", params={"persona_id": persona_id})
        self.assertEqual(response.status_code, 200)
        self.assertIsInstance(response.json(), list)
        self.assertTrue(len(response.json()) > 0)
        
        # Get session
        response = requests.get(f"{API_URL}/sessions/{session_id}")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()["id"], session_id)
        
        # Add message
        response = requests.post(
            f"{API_URL}/sessions/{session_id}/messages",
            json={"content": "Test message", "role": "user"},
            headers={"Authorization": f"Bearer {token}"}
        )
        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.json()["success"])
        
        # Get messages
        response = requests.get(f"{API_URL}/sessions/{session_id}/messages")
        self.assertEqual(response.status_code, 200)
        self.assertIn("messages", response.json())
        self.assertTrue(len(response.json()["messages"]) > 0)
        
        # Update session title
        response = requests.put(
            f"{API_URL}/sessions/{session_id}/title",
            params={"title": "Updated Test Session"},
            headers={"Authorization": f"Bearer {token}"}
        )
        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.json()["success"])
        
        # Export session
        response = requests.get(f"{API_URL}/sessions/{session_id}/export", params={"format": "json"})
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()["id"], session_id)
        
        # Delete session
        response = requests.delete(
            f"{API_URL}/sessions/{session_id}",
            headers={"Authorization": f"Bearer {token}"}
        )
        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.json()["success"])
    
    def test_06_voice_endpoints(self):
        """Test voice endpoints"""
        # Test text-to-speech
        response = requests.post(f"{API_URL}/voice/synthesize", params={"text": "Hello, Praxion!"})
        self.assertEqual(response.status_code, 200)
        self.assertTrue(len(response.content) > 0)
        
        # Test speech-to-text would require audio file, skipping for now

class TestPraxionModules(unittest.TestCase):
    """Test Praxion modules directly"""
    
    def test_01_llm_module(self):
        """Test LLM module"""
        sys.path.append(ROOT_DIR)
        from src.backend.llm import LLMEngine
        
        llm = LLMEngine()
        response = llm.generate("Hello, Praxion!")
        self.assertIsInstance(response, str)
        self.assertTrue(len(response) > 0)
    
    def test_02_persona_lock_module(self):
        """Test PersonaLock module"""
        sys.path.append(ROOT_DIR)
        from src.backend.persona_lock import PersonaLockSystem
        
        # Initialize with temporary directory
        import tempfile
        temp_dir = tempfile.mkdtemp()
        persona_lock = PersonaLockSystem(temp_dir)
        
        # Create persona
        persona = persona_lock.create_persona("Test Persona", "password123")
        self.assertIsInstance(persona, dict)
        self.assertEqual(persona["name"], "Test Persona")
        
        # Authenticate
        token = persona_lock.authenticate(persona["id"], "password123")
        self.assertIsNotNone(token)
        
        # Validate token
        self.assertTrue(persona_lock.validate_token(token))
        
        # Get current persona
        current_persona = persona_lock.get_current_persona()
        self.assertEqual(current_persona["id"], persona["id"])
        
        # Update persona
        updated_persona = persona_lock.update_persona(
            persona["id"],
            {"name": "Updated Test Persona"},
            token
        )
        self.assertEqual(updated_persona["name"], "Updated Test Persona")
        
        # Logout
        self.assertTrue(persona_lock.logout(token))
    
    def test_03_infinite_scroll_module(self):
        """Test InfiniteScroll module"""
        sys.path.append(ROOT_DIR)
        from src.backend.infinite_scroll import InfiniteScrollEngine
        
        # Initialize with temporary directory
        import tempfile
        temp_dir = tempfile.mkdtemp()
        infinite_scroll = InfiniteScrollEngine(temp_dir)
        
        # Create session
        session_id = infinite_scroll.create_session("test_persona", "Test Session")
        self.assertIsInstance(session_id, str)
        
        # Add message
        message = {
            "role": "user",
            "content": "Test message"
        }
        self.assertTrue(infinite_scroll.add_message(session_id, message))
        
        # Get messages
        messages = infinite_scroll.get_messages(session_id)
        self.assertEqual(len(messages), 1)
        self.assertEqual(messages[0]["content"], "Test message")
        
        # Get context
        context = infinite_scroll.get_context(session_id)
        self.assertEqual(len(context), 1)
        self.assertEqual(context[0]["content"], "Test message")
        
        # Update session title
        self.assertTrue(infinite_scroll.update_session_title(session_id, "Updated Test Session"))
        
        # Export session
        export_data = infinite_scroll.export_session(session_id)
        self.assertEqual(export_data["title"], "Updated Test Session")
        
        # Delete session
        self.assertTrue(infinite_scroll.delete_session(session_id))
    
    def test_04_voice_module(self):
        """Test Voice module"""
        sys.path.append(ROOT_DIR)
        from src.backend.voice import VoiceSystem
        
        voice = VoiceSystem()
        
        # Test text-to-speech
        audio_data = voice.text_to_speech("Hello, Praxion!")
        self.assertIsInstance(audio_data, bytes)
        self.assertTrue(len(audio_data) > 0)

def run_tests():
    """Run all tests"""
    # Create test suite
    suite = unittest.TestSuite()
    
    # Add tests
    suite.addTest(unittest.makeSuite(TestPraxionModules))
    suite.addTest(unittest.makeSuite(TestPraxionBackend))
    
    # Run tests
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    
    return result.wasSuccessful()

def main():
    parser = argparse.ArgumentParser(description="Praxion Integration Test Suite")
    parser.add_argument("--module", help="Test specific module")
    args = parser.parse_args()
    
    logger.info("Starting Praxion integration tests")
    
    if args.module:
        # Run specific module tests
        if args.module == "backend":
            suite = unittest.makeSuite(TestPraxionBackend)
        elif args.module == "modules":
            suite = unittest.makeSuite(TestPraxionModules)
        else:
            logger.error(f"Unknown module: {args.module}")
            return 1
        
        runner = unittest.TextTestRunner(verbosity=2)
        result = runner.run(suite)
        success = result.wasSuccessful()
    else:
        # Run all tests
        success = run_tests()
    
    if success:
        logger.info("All tests passed")
        return 0
    else:
        logger.error("Some tests failed")
        return 1

if __name__ == "__main__":
    sys.exit(main())
