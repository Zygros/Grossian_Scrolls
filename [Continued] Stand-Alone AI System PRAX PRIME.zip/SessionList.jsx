import React, { useState } from 'react';
import './SessionList.css';

const SessionList = ({ sessions, currentSessionId, onSelectSession, onDeleteSession }) => {
  const [editingSessionId, setEditingSessionId] = useState(null);
  const [editTitle, setEditTitle] = useState('');

  const handleEditStart = (session) => {
    setEditingSessionId(session.id);
    setEditTitle(session.title);
  };

  const handleEditCancel = () => {
    setEditingSessionId(null);
  };

  const handleEditSave = (sessionId) => {
    // This would typically call an API to update the session title
    // For now, we'll just update the UI
    setEditingSessionId(null);
  };

  const formatDate = (dateString) => {
    if (!dateString) return '';
    const date = new Date(dateString);
    return date.toLocaleString();
  };

  return (
    <div className="session-list">
      <h3>Conversations</h3>
      {sessions.length === 0 ? (
        <div className="no-sessions">No conversations yet</div>
      ) : (
        <ul>
          {sessions.map((session) => (
            <li 
              key={session.id} 
              className={session.id === currentSessionId ? 'active' : ''}
              onClick={() => onSelectSession(session.id)}
            >
              {editingSessionId === session.id ? (
                <div className="session-edit">
                  <input
                    type="text"
                    value={editTitle}
                    onChange={(e) => setEditTitle(e.target.value)}
                    autoFocus
                  />
                  <div className="edit-actions">
                    <button onClick={() => handleEditSave(session.id)}>Save</button>
                    <button onClick={handleEditCancel}>Cancel</button>
                  </div>
                </div>
              ) : (
                <>
                  <div className="session-info">
                    <div className="session-title">{session.title}</div>
                    <div className="session-date">{formatDate(session.last_updated)}</div>
                  </div>
                  <div className="session-actions">
                    <button 
                      className="edit-button" 
                      onClick={(e) => {
                        e.stopPropagation();
                        handleEditStart(session);
                      }}
                    >
                      ✎
                    </button>
                    <button 
                      className="delete-button" 
                      onClick={(e) => {
                        e.stopPropagation();
                        if (window.confirm('Are you sure you want to delete this conversation?')) {
                          onDeleteSession(session.id);
                        }
                      }}
                    >
                      ×
                    </button>
                  </div>
                </>
              )}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default SessionList;
