import React from 'react';
import './ChatInput.css';

const ChatInput = ({ value, onChange, onSubmit, isLoading }) => {
  const handleSubmit = (e) => {
    e.preventDefault();
    if (!value.trim()) return;
    onSubmit();
  };

  return (
    <form onSubmit={handleSubmit} className="chat-input-container">
      <input
        type="text"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder="Type a message..."
        disabled={isLoading}
        className="chat-input"
      />
      <button type="submit" disabled={isLoading} className="chat-submit-button">
        {isLoading ? 'Sending...' : 'Send'}
      </button>
    </form>
  );
};

export default ChatInput;
