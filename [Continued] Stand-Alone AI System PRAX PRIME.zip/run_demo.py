#!/usr/bin/env python3
"""
Praxion - End-to-End Demo Script
Demonstrates all features of Praxion with voice and visual components
"""

import os
import sys
import logging
import argparse
import time
import subprocess
import signal
import threading
import webbrowser
from pathlib import Path

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger("praxion.demo")

# Define paths
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
ROOT_DIR = os.path.abspath(os.path.join(SCRIPT_DIR, ".."))
SRC_DIR = os.path.join(ROOT_DIR, "src")
BACKEND_DIR = os.path.join(SRC_DIR, "backend")
UI_DIR = os.path.join(SRC_DIR, "ui")
DESKTOP_UI_DIR = os.path.join(UI_DIR, "desktop")

class PraxionDemo:
    """Class to manage Praxion demo"""
    
    def __init__(self):
        self.backend_process = None
        self.ui_process = None
    
    def start_backend(self):
        """Start the Praxion backend server"""
        if self.backend_process:
            logger.warning("Backend already running")
            return True
        
        logger.info("Starting Praxion backend server...")
        
        # Start server
        cmd = [sys.executable, "-m", "uvicorn", "src.backend.main:app", "--host", "0.0.0.0", "--port", "8000"]
        self.backend_process = subprocess.Popen(
            cmd,
            cwd=ROOT_DIR,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            preexec_fn=os.setsid
        )
        
        # Wait for server to start
        for i in range(30):
            try:
                import requests
                response = requests.get("http://localhost:8000/")
                if response.status_code == 200:
                    logger.info("Backend server started successfully")
                    return True
            except Exception:
                if i == 0:
                    logger.info("Waiting for backend server to start...")
                time.sleep(1)
        
        logger.error("Failed to start backend server")
        self.stop_backend()
        return False
    
    def stop_backend(self):
        """Stop the Praxion backend server"""
        if not self.backend_process:
            return
        
        logger.info("Stopping backend server...")
        
        # Kill process group
        try:
            os.killpg(os.getpgid(self.backend_process.pid), signal.SIGTERM)
            self.backend_process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            os.killpg(os.getpgid(self.backend_process.pid), signal.SIGKILL)
        except Exception as e:
            logger.error(f"Error stopping backend server: {str(e)}")
        
        self.backend_process = None
        logger.info("Backend server stopped")
    
    def start_ui(self, ui_type="desktop"):
        """Start the Praxion UI"""
        if self.ui_process:
            logger.warning("UI already running")
            return True
        
        logger.info(f"Starting Praxion {ui_type} UI...")
        
        if ui_type == "desktop":
            # Start desktop UI
            ui_dir = DESKTOP_UI_DIR
            cmd = ["npm", "run", "dev"]
        else:
            logger.error(f"Unsupported UI type: {ui_type}")
            return False
        
        self.ui_process = subprocess.Popen(
            cmd,
            cwd=ui_dir,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            preexec_fn=os.setsid
        )
        
        # Wait for UI to start
        for i in range(30):
            try:
                import requests
                response = requests.get("http://localhost:5173/")
                if response.status_code == 200:
                    logger.info("UI started successfully")
                    return True
            except Exception:
                if i == 0:
                    logger.info("Waiting for UI to start...")
                time.sleep(1)
        
        logger.error("Failed to start UI")
        self.stop_ui()
        return False
    
    def stop_ui(self):
        """Stop the Praxion UI"""
        if not self.ui_process:
            return
        
        logger.info("Stopping UI...")
        
        # Kill process group
        try:
            os.killpg(os.getpgid(self.ui_process.pid), signal.SIGTERM)
            self.ui_process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            os.killpg(os.getpgid(self.ui_process.pid), signal.SIGKILL)
        except Exception as e:
            logger.error(f"Error stopping UI: {str(e)}")
        
        self.ui_process = None
        logger.info("UI stopped")
    
    def open_browser(self):
        """Open browser to Praxion UI"""
        url = "http://localhost:5173/"
        logger.info(f"Opening browser to {url}")
        webbrowser.open(url)
    
    def run_voice_demo(self):
        """Run voice demo"""
        logger.info("Running voice demo...")
        
        try:
            # Import required modules
            sys.path.append(ROOT_DIR)
            from src.backend.voice import VoiceSystem
            
            voice = VoiceSystem()
            
            # Synthesize welcome message
            logger.info("Synthesizing welcome message...")
            welcome_text = "Hello, I am Praxion, your AI companion. I can help you with various tasks and answer your questions."
            audio_data = voice.text_to_speech(welcome_text)
            
            # Save audio to file
            audio_file = os.path.join(ROOT_DIR, "demo_welcome.wav")
            with open(audio_file, "wb") as f:
                f.write(audio_data)
            
            logger.info(f"Welcome message saved to {audio_file}")
            
            # Play audio
            logger.info("Playing welcome message...")
            try:
                import platform
                if platform.system() == "Windows":
                    os.system(f'start {audio_file}')
                elif platform.system() == "Darwin":  # macOS
                    os.system(f'afplay {audio_file}')
                else:  # Linux
                    os.system(f'aplay {audio_file}')
            except Exception as e:
                logger.error(f"Error playing audio: {str(e)}")
            
            return True
        except Exception as e:
            logger.error(f"Error running voice demo: {str(e)}")
            return False
    
    def run_demo(self, ui_type="desktop", open_browser=True, voice_demo=True):
        """Run the full Praxion demo"""
        logger.info("Starting Praxion demo...")
        
        # Start backend
        if not self.start_backend():
            logger.error("Failed to start backend")
            return False
        
        # Start UI
        if not self.start_ui(ui_type):
            logger.error("Failed to start UI")
            self.stop_backend()
            return False
        
        # Open browser
        if open_browser:
            self.open_browser()
        
        # Run voice demo
        if voice_demo:
            self.run_voice_demo()
        
        logger.info("Praxion demo is running")
        logger.info("Press Ctrl+C to stop the demo")
        
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            logger.info("Stopping demo...")
        finally:
            self.stop_ui()
            self.stop_backend()
        
        logger.info("Demo stopped")
        return True

def main():
    parser = argparse.ArgumentParser(description="Praxion End-to-End Demo")
    parser.add_argument("--ui", choices=["desktop"], default="desktop", help="UI type to run")
    parser.add_argument("--no-browser", action="store_true", help="Don't open browser")
    parser.add_argument("--no-voice", action="store_true", help="Don't run voice demo")
    args = parser.parse_args()
    
    demo = PraxionDemo()
    success = demo.run_demo(
        ui_type=args.ui,
        open_browser=not args.no_browser,
        voice_demo=not args.no_voice
    )
    
    return 0 if success else 1

if __name__ == "__main__":
    sys.exit(main())
