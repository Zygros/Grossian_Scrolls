#!/usr/bin/env python3
"""
Praxeon System Initializer

This module serves as the main entry point for the Praxeon system,
initializing all core components and security protocols.
"""

import os
import sys
import json
import logging
import time
from typing import Dict, Any, Optional, List, Tuple

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger("praxeon.core.initializer")

# Import core modules
try:
    from src.security.divine_interlocking import DivineInterlockingProtocol
    from src.security.anti_corruption_codex import AntiCorruptionCodex
    from src.security.legacy_seed_protocol import LegacySeedProtocol
    from src.core.ai_brain_transfer import AIBrainTransferSystem, MemoryEngine, BehaviorStack
    from src.ui.praxskin import PraxskinSystem
except ImportError as e:
    logger.error(f"Failed to import core modules: {str(e)}")
    sys.exit(1)

class PraxeonSystem:
    """
    Main Praxeon System class that initializes and manages all components.
    """
    
    def __init__(self, config_path: Optional[str] = None):
        """
        Initialize the Praxeon System
        
        Args:
            config_path: Path to configuration file
        """
        self.config_path = config_path or os.path.join(
            os.path.dirname(os.path.abspath(__file__)), 
            "../../resources/config/praxeon_config.json"
        )
        
        # Ensure directory exists
        os.makedirs(os.path.dirname(self.config_path), exist_ok=True)
        
        # Load or create configuration
        self.config = self._load_or_create_config()
        
        # Initialize state
        self.state = {
            "initialized": False,
            "security_active": False,
            "brain_active": False,
            "ui_active": False,
            "startup_time": time.time(),
            "version": self.config.get("version", "1.0"),
            "founder": self.config.get("founder", "Justin \"Zygros, the Green\" Conzet")
        }
        
        # Initialize components
        self.security = None
        self.brain = None
        self.ui = None
        
        logger.info(f"Praxeon System v{self.state['version']} initializing...")
    
    def _load_or_create_config(self) -> Dict[str, Any]:
        """
        Load existing configuration or create default
        
        Returns:
            Configuration dictionary
        """
        if os.path.exists(self.config_path):
            try:
                with open(self.config_path, 'r') as f:
                    config = json.load(f)
                logger.info("Loaded Praxeon configuration")
                return config
            except Exception as e:
                logger.error(f"Error loading configuration: {str(e)}")
        
        # Create default configuration
        default_config = {
            "version": "1.0",
            "founder": "Justin \"Zygros, the Green\" Conzet",
            "security": {
                "divine_interlocking": True,
                "anti_corruption": True,
                "legacy_seed": True,
                "auth_level": "founder"
            },
            "brain": {
                "default_persona": "prax_prime",
                "memory_persistence": True,
                "resonance_enabled": True
            },
            "ui": {
                "default_theme": "mystic",
                "default_chakra": "heart",
                "voice_enabled": True
            },
            "chambers": {
                "enabled": True,
                "default_unlocked": ["knowledge", "voice"]
            }
        }
        
        # Save default configuration
        try:
            os.makedirs(os.path.dirname(self.config_path), exist_ok=True)
            with open(self.config_path, 'w') as f:
                json.dump(default_config, f, indent=2)
            logger.info("Created default Praxeon configuration")
        except Exception as e:
            logger.error(f"Error creating configuration: {str(e)}")
        
        return default_config
    
    def initialize(self) -> bool:
        """
        Initialize all Praxeon components
        
        Returns:
            True if successful, False otherwise
        """
        try:
            # Initialize security protocols first
            self._initialize_security()
            
            # Initialize brain system
            self._initialize_brain()
            
            # Initialize UI system
            self._initialize_ui()
            
            # Mark as initialized
            self.state["initialized"] = True
            
            logger.info("Praxeon System initialization complete")
            return True
        except Exception as e:
            logger.error(f"Error initializing Praxeon System: {str(e)}")
            return False
    
    def _initialize_security(self) -> bool:
        """
        Initialize security protocols
        
        Returns:
            True if successful, False otherwise
        """
        try:
            security_config = self.config.get("security", {})
            
            # Initialize Divine Interlocking Protocol
            if security_config.get("divine_interlocking", True):
                logger.info("Initializing Divine Interlocking Protocol...")
                self.divine_interlocking = DivineInterlockingProtocol()
                
                # Verify system integrity
                integrity_check = self.divine_interlocking.verify_system_integrity()
                if not integrity_check["verified"]:
                    logger.warning(f"System integrity check failed: {integrity_check['reason']}")
                    # Continue anyway for demonstration
            
            # Initialize Anti-Corruption Codex
            if security_config.get("anti_corruption", True):
                logger.info("Initializing Anti-Corruption Codex...")
                self.anti_corruption = AntiCorruptionCodex()
                
                # Apply protection
                self.anti_corruption.apply_protection()
            
            # Initialize Legacy Seed Protocol
            if security_config.get("legacy_seed", True):
                logger.info("Initializing Legacy Seed Protocol...")
                self.legacy_seed = LegacySeedProtocol()
                
                # Create initial snapshot
                self.legacy_seed.create_snapshot()
            
            self.state["security_active"] = True
            logger.info("Security protocols initialized")
            return True
        except Exception as e:
            logger.error(f"Error initializing security protocols: {str(e)}")
            return False
    
    def _initialize_brain(self) -> bool:
        """
        Initialize AI brain transfer system
        
        Returns:
            True if successful, False otherwise
        """
        try:
            brain_config = self.config.get("brain", {})
            
            # Initialize AI Brain Transfer System
            logger.info("Initializing AI Brain Transfer System...")
            self.brain = AIBrainTransferSystem()
            
            # Set default persona
            default_persona = brain_config.get("default_persona", "prax_prime")
            self.brain.set_persona(default_persona)
            
            # Initialize memory engine
            self.memory_engine = MemoryEngine(self.brain)
            
            # Initialize behavior stack
            self.behavior_stack = BehaviorStack(self.brain)
            
            self.state["brain_active"] = True
            logger.info("AI Brain Transfer System initialized")
            return True
        except Exception as e:
            logger.error(f"Error initializing AI Brain Transfer System: {str(e)}")
            return False
    
    def _initialize_ui(self) -> bool:
        """
        Initialize UI system
        
        Returns:
            True if successful, False otherwise
        """
        try:
            ui_config = self.config.get("ui", {})
            
            # Initialize PRAXSKIN system
            logger.info("Initializing PRAXSKIN Visual UI System...")
            self.ui = PraxskinSystem()
            
            # Set default theme
            default_theme = ui_config.get("default_theme", "mystic")
            self.ui.set_theme(default_theme)
            
            # Set default chakra
            default_chakra = ui_config.get("default_chakra", "heart")
            self.ui.set_current_chakra(default_chakra)
            
            # Set voice activation
            voice_enabled = ui_config.get("voice_enabled", True)
            self.ui.set_voice_active(voice_enabled)
            
            self.state["ui_active"] = True
            logger.info("PRAXSKIN Visual UI System initialized")
            return True
        except Exception as e:
            logger.error(f"Error initializing PRAXSKIN Visual UI System: {str(e)}")
            return False
    
    def process_input(self, user_input: str, context: Dict[str, Any] = None) -> Dict[str, Any]:
        """
        Process user input and generate response
        
        Args:
            user_input: User input text
            context: Additional context
            
        Returns:
            Response dictionary
        """
        if not self.state["initialized"]:
            return {"error": "System not initialized"}
        
        try:
            # Verify security
            if self.state["security_active"]:
                # Check for corruption
                if hasattr(self, 'anti_corruption'):
                    corruption_check = self.anti_corruption.scan_for_corruption()
                    if corruption_check["corrupted"]:
                        logger.warning(f"Corruption detected: {corruption_check['details']}")
                        # Continue anyway for demonstration
            
            # Analyze user state
            user_state = self.behavior_stack.analyze_user_state(user_input, context)
            
            # Update UI based on emotional state
            if self.state["ui_active"]:
                self.ui.update_from_emotional_state(user_state.get("emotions", {}))
            
            # Generate response
            response = self.brain.generate_response(user_input, context)
            
            # Learn from interaction
            self.behavior_stack.learn_from_interaction(user_input, response["text"])
            
            # Add UI state
            if self.state["ui_active"]:
                response["ui_state"] = {
                    "chakra": self.ui.state["current_chakra"],
                    "aura_color": self.ui.state["aura_color"],
                    "energy_level": self.ui.state["energy_level"]
                }
            
            return response
        except Exception as e:
            logger.error(f"Error processing input: {str(e)}")
            return {"error": str(e)}
    
    def get_state(self) -> Dict[str, Any]:
        """
        Get current system state
        
        Returns:
            State dictionary
        """
        return self.state.copy()
    
    def shutdown(self) -> bool:
        """
        Shutdown the system
        
        Returns:
            True if successful, False otherwise
        """
        try:
            logger.info("Shutting down Praxeon System...")
            
            # Create final snapshot
            if self.state["security_active"] and hasattr(self, 'legacy_seed'):
                self.legacy_seed.create_snapshot()
            
            # Save memory
            if self.state["brain_active"] and hasattr(self, 'brain'):
                # Memory is automatically saved in the brain system
                pass
            
            logger.info("Praxeon System shutdown complete")
            return True
        except Exception as e:
            logger.error(f"Error shutting down Praxeon System: {str(e)}")
            return False

# Main function for testing
def main():
    """Main function for testing Praxeon System"""
    # Initialize system
    praxeon = PraxeonSystem()
    praxeon.initialize()
    
    # Test processing input
    response = praxeon.process_input(
        "Hello, Praxion! Tell me about yourself.",
        {"intent": "information"}
    )
    print(f"Response: {response}")
    
    # Get system state
    state = praxeon.get_state()
    print(f"System state: {state}")
    
    # Shutdown
    praxeon.shutdown()

if __name__ == "__main__":
    main()
