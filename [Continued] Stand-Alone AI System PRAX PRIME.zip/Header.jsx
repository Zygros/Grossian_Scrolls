import React from 'react';
import './Header.css';

const Header = ({ welcomeMessage }) => {
  return (
    <header className="app-header">
      <div className="logo-container">
        <div className="logo">P</div>
        <h1>Praxion</h1>
      </div>
      <p className="welcome-message">{welcomeMessage}</p>
    </header>
  );
};

export default Header;
